package model.bean;

/**
 * StudentReg.java
 *
 * Version 1.0
 *
 * Date: 23-08-2017
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 23-08-2017           TuTNC           Create
 */
public class StudentReg {
    private String firstName;
    private String lastName;
    private String title;
    private String institutionCode;
    private String institutionName;
    private double studentCode;
    private double phone;
    private String email;
    private String address;
    private String cityCode;
    private String cityName;
    private String stateCode;
    private String stateName;
    private String zipcode;
    private String countryCode;
    private String countryName;
    private String systemName;
    private String timePurchase;
    private String place;
    private String comment;
    
    /**
     * @return the firstName
     */
    public String getFirstName() {
        return firstName;
    }
    
    /**
     * @param firstName the firstName to set
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    
    /**
     * @return the lastName
     */
    public String getLastName() {
        return lastName;
    }
    
    /**
     * @param lastName the lastName to set
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    
    /**
     * @return the title
     */
    public String getTitle() {
        return title;
    }
    
    /**
     * @param title the title to set
     */
    public void setTitle(String title) {
        this.title = title;
    }
    
    /**
     * @return the institutionCode
     */
    public String getInstitutionCode() {
        return institutionCode;
    }
    
    /**
     * @param institutionCode the institutionCode to set
     */
    public void setInstitutionCode(String institutionCode) {
        this.institutionCode = institutionCode;
    }
    
    /**
     * @return the institutionName
     */
    public String getInstitutionName() {
        return institutionName;
    }
    
    /**
     * @param institutionName the institutionName to set
     */
    public void setInstitutionName(String institutionName) {
        this.institutionName = institutionName;
    }
    
    /**
     * @return the studentCode
     */
    public double getStudentCode() {
        return studentCode;
    }
    
    /**
     * @param studentCode the studentCode to set
     */
    public void setStudentCode(double studentCode) {
        this.studentCode = studentCode;
    }
    
    /**
     * @return the phone
     */
    public double getPhone() {
        return phone;
    }
    
    /**
     * @param phone the phone to set
     */
    public void setPhone(double phone) {
        this.phone = phone;
    }
    
    /**
     * @return the email
     */
    public String getEmail() {
        return email;
    }
    
    /**
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }
    
    /**
     * @return the address
     */
    public String getAddress() {
        return address;
    }
    
    /**
     * @param address the address to set
     */
    public void setAddress(String address) {
        this.address = address;
    }
    
    /**
     * @return the cityCode
     */
    public String getCityCode() {
        return cityCode;
    }
    
    /**
     * @param cityCode the cityCode to set
     */
    public void setCityCode(String cityCode) {
        this.cityCode = cityCode;
    }
    
    /**
     * @return the cityName
     */
    public String getCityName() {
        return cityName;
    }
    
    /**
     * @param cityName the cityName to set
     */
    public void setCityName(String cityName) {
        this.cityName = cityName;
    }
    
    /**
     * @return the stateCode
     */
    public String getStateCode() {
        return stateCode;
    }
    
    /**
     * @param stateCode the stateCode to set
     */
    public void setStateCode(String stateCode) {
        this.stateCode = stateCode;
    }
    
    /**
     * @return the stateName
     */
    public String getStateName() {
        return stateName;
    }
    
    /**
     * @param stateName the stateName to set
     */
    public void setStateName(String stateName) {
        this.stateName = stateName;
    }
    
    /**
     * @return the zipcode
     */
    public String getZipcode() {
        return zipcode;
    }
    
    /**
     * @param zipcode the zipcode to set
     */
    public void setZipcode(String zipcode) {
        this.zipcode = zipcode;
    }
    
    /**
     * @return the countryCode
     */
    public String getCountryCode() {
        return countryCode;
    }
    
    /**
     * @param countryCode the countryCode to set
     */
    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }
    
    /**
     * @return the countryName
     */
    public String getCountryName() {
        return countryName;
    }
    
    /**
     * @param countryName the countryName to set
     */
    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }
    
    /**
     * @return the systemName
     */
    public String getSystemName() {
        return systemName;
    }
    
    /**
     * @param systemName the systemName to set
     */
    public void setSystemName(String systemName) {
        this.systemName = systemName;
    }
    
    /**
     * @return the timePurchase
     */
    public String getTimePurchase() {
        return timePurchase;
    }
    
    /**
     * @param timePurchase the timePurchase to set
     */
    public void setTimePurchase(String timePurchase) {
        this.timePurchase = timePurchase;
    }
    
    /**
     * @return the place
     */
    public String getPlace() {
        return place;
    }
    
    /**
     * @param place the place to set
     */
    public void setPlace(String place) {
        this.place = place;
    }
    
    /**
     * @return the comment
     */
    public String getComment() {
        return comment;
    }
    
    /**
     * @param comment the comment to set
     */
    public void setComment(String comment) {
        this.comment = comment;
    }

    /**
     * @param firstName
     * @param lastName
     * @param title
     * @param institutionCode
     * @param studentCode
     * @param phone
     * @param email
     * @param address
     * @param cityCode
     * @param stateCode
     * @param zipcode
     * @param countryCode
     * @param systemName
     * @param timePurchase
     * @param place
     * @param comment
     */
    public StudentReg(String firstName, String lastName, String title, String institutionCode, double studentCode,
            double phone, String email, String address, String cityCode, String stateCode, String zipcode,
            String countryCode, String systemName, String timePurchase, String place, String comment) {
        super();
        this.firstName = firstName;
        this.lastName = lastName;
        this.title = title;
        this.institutionCode = institutionCode;
        this.studentCode = studentCode;
        this.phone = phone;
        this.email = email;
        this.address = address;
        this.cityCode = cityCode;
        this.stateCode = stateCode;
        this.zipcode = zipcode;
        this.countryCode = countryCode;
        this.systemName = systemName;
        this.timePurchase = timePurchase;
        this.place = place;
        this.comment = comment;
    }
    
    
}

package model.bean;

/**
 * Systems.java
 *
 * Version 1.0
 *
 * Date: 23-08-2017
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 23-08-2017           TuTNC           Create
 */
public class Systems {
    private String systemName;
    private String timePurchase;
    
    /**
     * @return the systemName
     */
    public String getSystemName() {
        return systemName;
    }
    
    /**
     * @param systemName the systemName to set
     */
    public void setSystemName(String systemName) {
        this.systemName = systemName;
    }
    
    /**
     * @return the timePurchase
     */
    public String getTimePurchase() {
        return timePurchase;
    }
    
    /**
     * @param timePurchase the timePurchase to set
     */
    public void setTimePurchase(String timePurchase) {
        this.timePurchase = timePurchase;
    }
}

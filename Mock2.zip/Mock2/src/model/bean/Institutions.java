package model.bean;

/**
 * Institutions.java
 *
 * Version 1.0
 *
 * Date: 23-08-2017
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 23-08-2017           TuTNC           Create
 */
public class Institutions {
    private String institutionCode;
    private String institutionName;
    private String foundedDate;
    private String level;
    
    /**
     * @return the institutionCode
     */
    public String getInstitutionCode() {
        return institutionCode;
    }
    
    /**
     * @param institutionCode the institutionCode to set
     */
    public void setInstitutionCode(String institutionCode) {
        this.institutionCode = institutionCode;
    }
    
    /**
     * @return the institutionName
     */
    public String getInstitutionName() {
        return institutionName;
    }
    
    /**
     * @param institutionName the institutionName to set
     */
    public void setInstitutionName(String institutionName) {
        this.institutionName = institutionName;
    }
    
    /**
     * @return the foundedDate
     */
    public String getFoundedDate() {
        return foundedDate;
    }
    
    /**
     * @param foundedDate the foundedDate to set
     */
    public void setFoundedDate(String foundedDate) {
        this.foundedDate = foundedDate;
    }
    
    /**
     * @return the level
     */
    public String getLevel() {
        return level;
    }
    
    /**
     * @param level the level to set
     */
    public void setLevel(String level) {
        this.level = level;
    }
}

package model.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import model.bean.Cities;
import model.bean.Countries;
import model.bean.States;
import model.bean.StudentReg;
import model.bean.Systems;

/**
 * StudentRegDAO.java
 *
 * Version 1.0
 *
 * Date: 23-08-2017
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 23-08-2017           TuTNC           Create
 */
public class StudentRegDAO {
    Statement stmt;
    PreparedStatement pstm;
    CallableStatement calstmt;
    ResultSet rs;

    BaseDAO baseDAO = new BaseDAO();
    Connection connection;
    
    public ArrayList<Cities> getListCities(String country) throws SQLException {
        connection = baseDAO.getConnection();
        
        String sql= "SELECT CODE, NAME FROM CITIES WHERE COUNTRY = N'" + country + "'";
        rs = null;
        ArrayList<Cities> list = new ArrayList<Cities>();
        Cities city;
        
        try {
            stmt = connection.createStatement();
            rs = stmt.executeQuery(sql);
            
            while(rs.next()){
                city = new Cities();
                city.setCode(rs.getString("CODE"));
                city.setName(rs.getString("NAME"));
                list.add(city);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            connection.close();
        }
        
        return list;
    }

    public ArrayList<States> getListStates(String country) throws SQLException {
        connection = baseDAO.getConnection();
        
        String sql= "SELECT CODE, NAME FROM STATES WHERE COUNTRY = N'" + country + "'";
        rs = null;
        ArrayList<States> list = new ArrayList<States>();
        States state;
        
        try {
            stmt = connection.createStatement();
            rs = stmt.executeQuery(sql);
            
            while(rs.next()){
                state = new States();
                state.setCode(rs.getString("CODE"));
                state.setName(rs.getString("NAME"));
                list.add(state);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            connection.close();
        }
        
        return list;
    }

    public ArrayList<Countries> getListCountries() throws SQLException {
        connection = baseDAO.getConnection();
        
        String sql= "SELECT CODE, NAME FROM COUNTRIES";
        rs = null;
        ArrayList<Countries> list = new ArrayList<Countries>();
        Countries country;
        
        try {
            stmt = connection.createStatement();
            rs = stmt.executeQuery(sql);
            
            while(rs.next()){
                country = new Countries();
                country.setCode(rs.getString("CODE"));
                country.setName(rs.getString("NAME"));
                list.add(country);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            connection.close();
        }
        
        return list;
    }

    public ArrayList<Systems> getListSystemName() throws SQLException {
        connection = baseDAO.getConnection();
        
        String sql= "SELECT DISTINCT SYSTEM_NAME FROM SYSTEMS";
        rs = null;
        ArrayList<Systems> list = new ArrayList<Systems>();
        Systems systemName;
        
        try {
            stmt = connection.createStatement();
            rs = stmt.executeQuery(sql);
            
            while(rs.next()){
                systemName = new Systems();
                systemName.setSystemName(rs.getString("SYSTEM_NAME"));
                list.add(systemName);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            connection.close();
        }
        
        return list;
    }

    public ArrayList<Systems> getListTimePurchase(String systemName) throws SQLException {
        connection = baseDAO.getConnection();
        
        String sql= " SELECT DISTINCT TIME_PURCHASE FROM SYSTEMS WHERE SYSTEM_NAME = N'" + systemName + "'";
        rs = null;
        ArrayList<Systems> list = new ArrayList<Systems>();
        Systems timePurchase;
        
        try {
            stmt = connection.createStatement();
            rs = stmt.executeQuery(sql);
            
            while(rs.next()){
                timePurchase = new Systems();
                timePurchase.setTimePurchase(rs.getString("TIME_PURCHASE"));
                list.add(timePurchase);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            connection.close();
        }
        
        return list;
    }

    public boolean reg(StudentReg studentReg) throws SQLException {
        connection = baseDAO.getConnection();
        
        String sql = String.format("INSERT INTO STUDENT_REG (FIRST_NAME, LAST_NAME, TITLE, INSTITUTION, STUDENT_CODE, "
                    + " PHONE, EMAIL, ADDRESS, CITY, STATE, ZIPCODE, COUNTRY, SYSTEM_NAME, TIME_PURCHASE, PLACE, COMMENT) "
                    + " VALUES (N'%s',N'%s',N'%s',N'%s','%f','%f',N'%s',N'%s',N'%s',N'%s',N'%s',N'%s',N'%s',N'%s',N'%s',N'%s')",
                    studentReg.getFirstName(), studentReg.getLastName(), studentReg.getTitle(), studentReg.getInstitutionCode(), 
                    studentReg.getStudentCode(), studentReg.getPhone(), studentReg.getEmail(), studentReg.getAddress(), 
                    studentReg.getCityCode(), studentReg.getStateCode(), studentReg.getZipcode(), studentReg.getCountryCode(), 
                    studentReg.getSystemName(), studentReg.getTimePurchase(), studentReg.getPlace(), studentReg.getComment());
                    
        try {
            stmt = connection.createStatement();
            stmt.executeUpdate(sql);
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            connection.close();
        }
    }

    public boolean checkEmail(String email) throws SQLException {
        connection = baseDAO.getConnection();
        
        String sql= "SELECT EMAIL FROM STUDENT_REG WHERE EMAIL = N'" + email + "'";
        rs = null;
        
        try {
            stmt = connection.createStatement();
            rs = stmt.executeQuery(sql);
            
            if(rs.next()){
                return true;
            } else {
                return false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            connection.close();
        }
        return false;
    }

    public boolean checkStudent(double studentCode, String institutionCode) throws SQLException {
        connection = baseDAO.getConnection();
        
        String sql= "SELECT 1 FROM STUDENT_REG WHERE STUDENT_CODE = N'" + studentCode + "' AND INSTITUTION = N'" + institutionCode + "'";
        rs = null;
        
        try {
            stmt = connection.createStatement();
            rs = stmt.executeQuery(sql);
            
            if(rs.next()){
                return true;
            } else {
                return false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            connection.close();
        }
        return false;
    }

}

package model.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * BaseDAO.java
 *
 * Version 1.0
 *
 * Date: 23-08-2017
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 23-08-2017           TuTNC           Create
 */
public class BaseDAO {
	String url = "jdbc:sqlserver://localhost:1433;databaseName=MCL";
	String userName = "sa";
	String password = "Abcde12345";
	Connection connection;
	
	Connection getConnection(){
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			connection = DriverManager.getConnection(url, userName, password);
			System.out.println("Ket noi thanh cong");
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Ket noi loi");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			System.out.println("Ket noi loi");
		}
		return connection;
	}

}

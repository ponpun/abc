package model.bo;

import java.sql.SQLException;
import java.util.ArrayList;

import model.bean.Cities;
import model.bean.Countries;
import model.bean.States;
import model.bean.StudentReg;
import model.bean.Systems;
import model.dao.StudentRegDAO;

/**
 * StudentRegBO.java
 *
 * Version 1.0
 *
 * Date: 23-08-2017
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 23-08-2017           TuTNC           Create
 */
public class StudentRegBO {
    StudentRegDAO studentRegDAO = new StudentRegDAO();
    
    public ArrayList<Cities> getListCities(String country) throws SQLException {
        return studentRegDAO.getListCities(country);
    }

    public ArrayList<States> getListStates(String country) throws SQLException {
        return studentRegDAO.getListStates(country);
    }

    public ArrayList<Countries> getListCountries() throws SQLException {
        return studentRegDAO.getListCountries();
    }

    public ArrayList<Systems> getListSystemName() throws SQLException {
        return studentRegDAO.getListSystemName();
    }

    public ArrayList<Systems> getListTimePurchase(String systemName) throws SQLException {
        return studentRegDAO.getListTimePurchase(systemName);
    }

    public boolean reg(StudentReg studentReg) throws SQLException {
        return studentRegDAO.reg(studentReg);
    }
    
    public boolean checkEmail(String email) throws SQLException {
        return studentRegDAO.checkEmail(email);
    }
    
    public boolean checkStudent(double studentCode, String institutionCode) throws SQLException {
        return studentRegDAO.checkStudent(studentCode, institutionCode);
    }

}

package form;

import java.util.ArrayList;

import org.apache.struts.action.ActionForm;

import model.bean.DMHang;
import model.bean.MatHang;
import model.bean.ThuongHieu;

public class ListMatHangForm extends ActionForm{

	private String tenMH;
	private String maDM;
	private String maTH;
	
	private int page;
	private int totalPages;
	
	private ArrayList<MatHang> listMatHang;
	private ArrayList<ThuongHieu> listThuongHieu;
	private ArrayList<DMHang> listDMHang;
	
	
	public String getTenMH() {
		return tenMH;
	}
	public void setTenMH(String tenMH) {
		this.tenMH = tenMH;
	}
	public String getMaDM() {
		return maDM;
	}
	public void setMaDM(String maDM) {
		this.maDM = maDM;
	}
	public String getMaTH() {
		return maTH;
	}
	public void setMaTH(String maTH) {
		this.maTH = maTH;
	}
	public int getPage() {
		return page;
	}
	public void setPage(int page) {
		this.page = page;
	}
	public int getTotalPages() {
		return totalPages;
	}
	public void setTotalPages(int totalPages) {
		this.totalPages = totalPages;
	}
	public ArrayList<MatHang> getListMatHang() {
		return listMatHang;
	}
	public void setListMatHang(ArrayList<MatHang> listMatHang) {
		this.listMatHang = listMatHang;
	}
	public ArrayList<ThuongHieu> getListThuongHieu() {
		return listThuongHieu;
	}
	public void setListThuongHieu(ArrayList<ThuongHieu> listThuongHieu) {
		this.listThuongHieu = listThuongHieu;
	}
	public ArrayList<DMHang> getListDMHang() {
		return listDMHang;
	}
	public void setListDMHang(ArrayList<DMHang> listDMHang) {
		this.listDMHang = listDMHang;
	}
	
	
}

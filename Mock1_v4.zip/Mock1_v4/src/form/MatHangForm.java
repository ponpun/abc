package form;

import java.util.ArrayList;

import org.apache.struts.action.ActionForm;

import model.bean.DMHang;
import model.bean.MatHang;
import model.bean.ThuongHieu;

public class MatHangForm extends ActionForm{

	private String maMH;
	private String tenMH;
	private String maDM;
	private String tenDM;
	private String maTH;
	private String tenTH;
	private String DVT;
	private int soLuong;
	private String moTa;
	private String HSD;
	private int donGia;
	private String submit;
	
	private ArrayList<ThuongHieu> listThuongHieu;
	private ArrayList<DMHang> listDMHang;
	private MatHang matHang;
	public String getMaMH() {
		return maMH;
	}
	public void setMaMH(String maMH) {
		this.maMH = maMH;
	}
	public String getTenMH() {
		return tenMH;
	}
	public void setTenMH(String tenMH) {
		this.tenMH = tenMH;
	}
	public String getMaDM() {
		return maDM;
	}
	public void setMaDM(String maDM) {
		this.maDM = maDM;
	}
	public String getTenDM() {
		return tenDM;
	}
	public void setTenDM(String tenDM) {
		this.tenDM = tenDM;
	}
	public String getMaTH() {
		return maTH;
	}
	public void setMaTH(String maTH) {
		this.maTH = maTH;
	}
	public String getTenTH() {
		return tenTH;
	}
	public void setTenTH(String tenTH) {
		this.tenTH = tenTH;
	}
	
	public String getDVT() {
		return DVT;
	}
	public void setDVT(String dVT) {
		DVT = dVT;
	}
	public int getSoLuong() {
		return soLuong;
	}
	public void setSoLuong(int soLuong) {
		this.soLuong = soLuong;
	}
	public String getMoTa() {
		return moTa;
	}
	public void setMoTa(String moTa) {
		this.moTa = moTa;
	}
	
	public String getHSD() {
		return HSD;
	}
	public void setHSD(String hSD) {
		HSD = hSD;
	}
	public int getDonGia() {
		return donGia;
	}
	public void setDonGia(int donGia) {
		this.donGia = donGia;
	}
	public ArrayList<ThuongHieu> getListThuongHieu() {
		return listThuongHieu;
	}
	public void setListThuongHieu(ArrayList<ThuongHieu> listThuongHieu) {
		this.listThuongHieu = listThuongHieu;
	}
	public ArrayList<DMHang> getListDMHang() {
		return listDMHang;
	}
	public void setListDMHang(ArrayList<DMHang> listDMHang) {
		this.listDMHang = listDMHang;
	}
	public MatHang getMatHang() {
		return matHang;
	}
	public void setMatHang(MatHang matHang) {
		this.matHang = matHang;
	}
	public String getSubmit() {
		return submit;
	}
	public void setSubmit(String submit) {
		this.submit = submit;
	}
	
	
	
}

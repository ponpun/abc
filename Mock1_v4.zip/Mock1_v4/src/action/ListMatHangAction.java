package action;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import form.ListMatHangForm;
import model.bean.DMHang;
import model.bean.MatHang;
import model.bean.ThuongHieu;
import model.bo.MatHangBO;

public class ListMatHangAction extends Action{
	int first = 0, pages = 1, totalPerPage = 10, totalPages = 0;
	MatHangBO matHangBO = new MatHangBO();
	
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		response.setContentType("text/html;charset=UTF-8");
		request.setCharacterEncoding("UTF-8");
		     
		ListMatHangForm listMatHangForm = (ListMatHangForm) form;
		
		//lay page hien tai
		/*if (listMatHangForm.getPage() != 0) {*/
			pages = listMatHangForm.getPage();
		/*} else {
			pages = 1;
		}*/
				
		//lay ds thuong hieu		
		ArrayList<ThuongHieu> listThuongHieu = matHangBO.getListThuongHieu();
		listMatHangForm.setListThuongHieu(listThuongHieu);
		
		//lay ds danh muc
		ArrayList<DMHang> listDMHang = matHangBO.getListDMHang();
		listMatHangForm.setListDMHang(listDMHang);
		
		//lay ds mat hang
		ArrayList<MatHang> listMatHang;
		String tenMH = listMatHangForm.getTenMH();
		if (tenMH != null ){
			byte[] b = tenMH.getBytes("ISO-8859-1");
			tenMH = new String(b, "UTF-8");
		}
		listMatHangForm.setTenMH(tenMH);
				
		String maTH = listMatHangForm.getMaTH();
		String maDM = listMatHangForm.getMaDM();
		if((maTH == null || maTH.length() == 0) && (maDM == null || maDM.length() == 0)
				&& (tenMH == null || tenMH.length() == 0)){		
			pagination(matHangBO.countRows());
			listMatHang = matHangBO.getListMatHang(first, totalPerPage);
		} else {
			pagination(matHangBO.countRows(tenMH, maTH, maDM));
			listMatHang = matHangBO.getListMatHang(first, totalPerPage, tenMH, maTH, maDM);
		}
		listMatHangForm.setListMatHang(listMatHang);
		
		listMatHangForm.setTotalPages(totalPages);
				
		return mapping.findForward("listMatHang");
	}

	// phan trang
		private void pagination(int total) {		
			//tong so pages
			if (total % totalPerPage != 0 || total == 0){
				totalPages = total / totalPerPage + 1;
			} else {
				totalPages = total / totalPerPage;
			}
			
			//giới hạn pages trong khoảng 1 đến totalPages
			if (pages > totalPages){
				pages = totalPages;
			} else if (pages < 1) {
				pages = 1;
			}
			
			//tìm first
			first = (pages - 1) * totalPerPage;
		}
}

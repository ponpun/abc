package action;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import form.MatHangForm;
import model.bean.DMHang;
import model.bean.ThuongHieu;
import model.bo.MatHangBO;

public class AddMatHangAction extends Action{
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		request.setCharacterEncoding("UTF-8");
		
		MatHangForm matHangForm = (MatHangForm) form;
		
		//lay ds thuong hieu
		MatHangBO matHangBO = new MatHangBO();
		ArrayList<ThuongHieu> listThuongHieu = matHangBO.getListThuongHieu();
		matHangForm.setListThuongHieu(listThuongHieu);
				
		//lay ds danh muc
		ArrayList<DMHang> listDMHang = matHangBO.getListDMHang();
		matHangForm.setListDMHang(listDMHang);
		
		matHangForm.setMaMH(matHangBO.viewMaMH());
		
		String tenMH = matHangForm.getTenMH();
		if (tenMH != null ){
			byte[] b = tenMH.getBytes("ISO-8859-1");
			tenMH = new String(b, "UTF-8");
		}
		matHangForm.setTenMH(tenMH);
		
		String submit = matHangForm.getSubmit();
		if (submit != null ){
			byte[] b = submit.getBytes("ISO-8859-1");
			submit = new String(b, "UTF-8");
		}
		matHangForm.setSubmit(submit);
		
		if("Xác nhận".equals(submit)){		//nhan nut Xac nhan o trang Them mat hang
			String maMH = matHangForm.getMaMH();
			tenMH = matHangForm.getTenMH();
			String maTH= matHangForm.getMaTH();
			String maDM = matHangForm.getMaDM();
			String hSD = matHangForm.getHSD();
			String dVT = matHangForm.getDVT();
			String moTa= matHangForm.getMoTa();
			int donGia = matHangForm.getDonGia();
			int soLuong = matHangForm.getSoLuong();
			
			matHangBO.addMatHangaddMatHang(maMH, tenMH, maTH, maDM, hSD, donGia, dVT, soLuong, moTa);
			return mapping.findForward("themMHxong");
		} else {											//chuyen sang trang Them mat hang
			return mapping.findForward("themMH");
		}
		
	}
}

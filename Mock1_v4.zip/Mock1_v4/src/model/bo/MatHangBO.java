package model.bo;

import java.sql.SQLException;
import java.util.ArrayList;

import model.bean.DMHang;
import model.bean.MatHang;
import model.bean.ThuongHieu;
import model.dao.MatHangDAO;

public class MatHangBO {
	
	MatHangDAO matHangDAO = new MatHangDAO();
	
	public ArrayList<ThuongHieu> getListThuongHieu() {
		// TODO Auto-generated method stub
		return matHangDAO.getListThuongHieu();
	}

	public ArrayList<DMHang> getListDMHang() {
		// TODO Auto-generated method stub
		return matHangDAO.getListDMHang();
	}

	public ArrayList<MatHang> getListMatHang() {
		// TODO Auto-generated method stub
		return matHangDAO.getListMatHang();
	}

	public ArrayList<MatHang> getListMatHang(String tenMH, String maTH, String maDM) {
		// TODO Auto-generated method stub
		return matHangDAO.getListMatHang(tenMH, maTH, maDM);
	}
	
	public void addMatHangaddMatHang(String maMH, String tenMH, String maTH, String maDM, 
			String hSD, int donGia, String dVT, int soLuong, String moTa ){
		matHangDAO.addMatHangaddMatHang(maMH, tenMH, maTH, maDM, hSD, donGia, dVT, soLuong, moTa);
	}
	
	public String viewMaMH(){
		return matHangDAO.viewMaMH();
	}

	public int countRows() {
		return matHangDAO.countRows();
	}

	public ArrayList<MatHang> getListMatHang(int first, int last) {
		return matHangDAO.getListMatHang(first, last);
	}

	public int countRows(String tenMH, String maTH, String maDM) {
		return matHangDAO.countRows(tenMH, maTH, maDM);
	}

	public ArrayList<MatHang> getListMatHang(int first, int last, String tenMH, String maTH, String maDM) {
		return matHangDAO.getListMatHang(first, last, tenMH, maTH, maDM);
	}
}

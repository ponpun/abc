package model.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import model.bean.DMHang;
import model.bean.MatHang;
import model.bean.ThuongHieu;

public class MatHangDAO {

	Statement stmt;
	PreparedStatement pstm;
	CallableStatement calstmt;
	ResultSet rs;

	BaseDAO baseDAO = new BaseDAO();
	Connection connection;
	
	public ArrayList<ThuongHieu> getListThuongHieu() {
		connection = baseDAO.getConnection();
		
		String sql=	"SELECT MaTH, TenTH FROM ThuongHieu";
		rs = null;
		try {
			stmt = connection.createStatement();
			rs = stmt.executeQuery(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		ArrayList<ThuongHieu> list = new ArrayList<ThuongHieu>();
		ThuongHieu thuongHieu;
		try {
			while(rs.next()){
				thuongHieu = new ThuongHieu();
				thuongHieu.setMaTH(rs.getString("MaTH"));
				thuongHieu.setTenTH(rs.getString("TenTH"));
				list.add(thuongHieu);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	public ArrayList<DMHang> getListDMHang() {
		connection = baseDAO.getConnection();
		
		String sql=	"SELECT MaDM, TenDM FROM DMHang";
		rs = null;
		try {
			Statement stmt = connection.createStatement();
			rs = stmt.executeQuery(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		ArrayList<DMHang> list = new ArrayList<DMHang>();
		DMHang dmHang;
		try {
			while(rs.next()){
				dmHang = new DMHang();
				dmHang.setMaDM(rs.getString("MaDM"));
				dmHang.setTenDM(rs.getString("TenDM"));
				list.add(dmHang);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	public ArrayList<MatHang> getListMatHang() {
		connection = baseDAO.getConnection(); 
		
		String sql=	"SELECT MaMH, TenMH, TenDM, TenTH, HSD, DonGia, DVT, SoLuong, MoTa "
				+ " FROM MatHang, DMHang, ThuongHieu "
				+ " WHERE MatHang.MaDM=DMHang.MaDM and MatHang.MaTH=ThuongHieu.MaTH";
		
		rs = null;
		try {
			stmt = connection.createStatement();
			rs = stmt.executeQuery(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		ArrayList<MatHang> list = new ArrayList<MatHang>();
		MatHang matHang;
		try {
			while(rs.next()){
				matHang = new MatHang();
				matHang.setMaMH(rs.getString("MaMH"));
				matHang.setTenMH(rs.getString("TenMH"));
				matHang.setTenDM(rs.getString("TenDM"));
				matHang.setTenTH(rs.getString("TenTH"));
				matHang.setHSD(rs.getString("HSD"));
				matHang.setDonGia(rs.getInt("DonGia"));
				matHang.setDVT(rs.getString("DVT"));
				matHang.setSoLuong(rs.getInt("SoLuong"));
				matHang.setMoTa(rs.getString("MoTa"));
				list.add(matHang);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	public ArrayList<MatHang> getListMatHang(String tenMH, String maTH, String maDM) {
		connection = baseDAO.getConnection();
		
		String sql;
		if (tenMH == null || tenMH.length() == 0){
			if(maTH == ""  && maDM != ""){
				sql=	"SELECT MaMH, TenMH, TenDM, TenTH, HSD, DonGia, DVT, SoLuong, MoTa "
						+ " FROM MatHang, DMHang, ThuongHieu "
						+ " WHERE MatHang.MaDM=DMHang.MaDM and MatHang.MaTH=ThuongHieu.MaTH"
						+ " and MatHang.MaDM='"+maDM+"'";
			}else{
				if(maTH != "" && maDM == ""){
					sql=	"SELECT MaMH, TenMH, TenDM, TenTH, HSD, DonGia, DVT, SoLuong, MoTa "
							+ " FROM MatHang, DMHang, ThuongHieu "
							+ " WHERE MatHang.MaDM=DMHang.MaDM and MatHang.MaTH=ThuongHieu.MaTH"
							+ " and MatHang.MaTH='"+maTH+"'";
				}else{
						sql=	"SELECT MaMH, TenMH, TenDM, TenTH, HSD, DonGia, DVT, SoLuong, MoTa "
								+ " FROM MatHang, DMHang, ThuongHieu "
								+ " WHERE MatHang.MaDM=DMHang.MaDM and MatHang.MaTH=ThuongHieu.MaTH"
								+ " and MatHang.MaTH='"+maTH+"' and MatHang.MaDM='"+maDM+"'";
				}
			}
		} else {
			sql=	"SELECT MaMH, TenMH, TenDM, TenTH, HSD, DonGia, DVT, SoLuong, MoTa "
					+ " FROM MatHang, DMHang, ThuongHieu "
					+ " WHERE MatHang.MaDM=DMHang.MaDM and MatHang.MaTH=ThuongHieu.MaTH"
					+ " and TenMH=N'"+tenMH+"'";
		}
		
		rs = null;
		try {
			stmt = connection.createStatement();
			rs = stmt.executeQuery(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		ArrayList<MatHang> list = new ArrayList<MatHang>();
		MatHang matHang;
		try {
			while(rs.next()){
				matHang = new MatHang();
				matHang.setMaMH(rs.getString("MaMH"));
				matHang.setTenMH(rs.getString("TenMH"));
				matHang.setTenDM(rs.getString("TenDM"));
				matHang.setTenTH(rs.getString("TenTH"));
				matHang.setHSD(rs.getString("HSD"));
				matHang.setDonGia(rs.getInt("DonGia"));
				matHang.setDVT(rs.getString("DVT"));
				matHang.setSoLuong(rs.getInt("SoLuong"));
				matHang.setMoTa(rs.getString("MoTa"));
				list.add(matHang);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}
	
	public void addMatHangaddMatHang(String maMH, String tenMH, String maTH, String maDM, 
			String hSD, int donGia, String dVT, int soLuong, String moTa ){
		connection = baseDAO.getConnection();
		
		String sql=	String.format(" INSERT INTO MatHang(MaMH, TenMH, MaTH, MaDM, HSD, DonGia, DVT, SoLuong, MoTa) "+
					" VALUES ( '%s',N'%s','%s','%s','%s','%s',N'%s','%s',N'%s' )", maMH, tenMH, maTH, maDM, hSD, donGia, dVT, soLuong,  moTa);
		System.out.println(sql);
		try {
			Statement stmt = connection.createStatement();
			stmt.executeUpdate(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public String viewMaMH(){
		connection = baseDAO.getConnection();
		String maMH = null;
		
		try {
			calstmt = connection.prepareCall("{call SP_HIENTHIMaMH}");
			rs = calstmt.executeQuery();
			if (rs.next()){
				maMH = rs.getString("MaMH");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return maMH;
	}

	public int countRows() {
		connection = baseDAO.getConnection();
		
		String sql=	"SELECT count(MaMH) FROM MatHang";
		try {
			connection = baseDAO.getConnection();
			stmt = connection.createStatement();
			rs = stmt.executeQuery(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		int count = 0;
		try {
			while (rs.next()) {
				count += rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return count;
	}

	public ArrayList<MatHang> getListMatHang(int first, int last) {
		connection = baseDAO.getConnection();
		String sql = "SELECT MaMH, TenMH, TenDM, TenTH, HSD, DonGia, DVT, SoLuong, MoTa "
				+ " FROM MatHang, DMHang, ThuongHieu "
				+ " WHERE MatHang.MaDM = DMHang.MaDM and MatHang.MaTH = ThuongHieu.MaTH "
				+ " ORDER BY MaMH offset " + first + " rows fetch next " + last	+ " rows only";
		rs = null;
		try {
			stmt = connection.createStatement();
			rs = stmt.executeQuery(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		ArrayList<MatHang> list = new ArrayList<MatHang>();
		MatHang matHang;
		try {
			while(rs.next()){
				matHang = new MatHang();
				matHang.setMaMH(rs.getString("MaMH"));
				matHang.setTenMH(rs.getString("TenMH"));
				matHang.setTenDM(rs.getString("TenDM"));
				matHang.setTenTH(rs.getString("TenTH"));
				matHang.setHSD(rs.getString("HSD"));
				matHang.setDonGia(rs.getInt("DonGia"));
				matHang.setDVT(rs.getString("DVT"));
				matHang.setSoLuong(rs.getInt("SoLuong"));
				matHang.setMoTa(rs.getString("MoTa"));
				list.add(matHang);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	public int countRows(String tenMH, String maTH, String maDM) {
		String sql;
		if (tenMH == null || tenMH.length() == 0){
			if(maTH == ""  && maDM != ""){
				sql=	"SELECT count(MaMH) "
						+ " FROM MatHang, DMHang, ThuongHieu "
						+ " WHERE MatHang.MaDM=DMHang.MaDM and MatHang.MaTH=ThuongHieu.MaTH"
						+ " and MatHang.MaDM='"+maDM+"'";
			}else{
				if(maTH != "" && maDM == ""){
					sql=	"SELECT count(MaMH) "
							+ " FROM MatHang, DMHang, ThuongHieu "
							+ " WHERE MatHang.MaDM=DMHang.MaDM and MatHang.MaTH=ThuongHieu.MaTH"
							+ " and MatHang.MaTH='"+maTH+"''";
				}else{
						sql=	"SELECT count(MaMH) "
								+ " FROM MatHang, DMHang, ThuongHieu "
								+ " WHERE MatHang.MaDM=DMHang.MaDM and MatHang.MaTH=ThuongHieu.MaTH"
								+ " and MatHang.MaTH='"+maTH+"' and MatHang.MaDM='"+maDM+"'";
				}
			}
		} else {
			sql=	"SELECT count(MaMH) "
					+ " FROM MatHang, DMHang, ThuongHieu "
					+ " WHERE MatHang.MaDM=DMHang.MaDM and MatHang.MaTH=ThuongHieu.MaTH"
					+ " and TenMH=N'"+tenMH+"'";
		}
		
		try {
			connection = baseDAO.getConnection();
			stmt = connection.createStatement();
			rs = stmt.executeQuery(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		int count = 0;
		try {
			while (rs.next()) {
				count += rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return count;
	}

	public ArrayList<MatHang> getListMatHang(int first, int last, String tenMH, String maTH, String maDM) {
		connection = baseDAO.getConnection();
		String sql;
		if (tenMH == null || tenMH.length() == 0){
			if(maTH == ""  && maDM != ""){
				sql=	"SELECT MaMH, TenMH, TenDM, TenTH, HSD, DonGia, DVT, SoLuong, MoTa "
						+ " FROM MatHang, DMHang, ThuongHieu "
						+ " WHERE MatHang.MaDM=DMHang.MaDM and MatHang.MaTH=ThuongHieu.MaTH"
						+ " and MatHang.MaDM='"+maDM+"'";
			}else{
				if(maTH != "" && maDM == ""){
					sql=	"SELECT MaMH, TenMH, TenDM, TenTH, HSD, DonGia, DVT, SoLuong, MoTa "
							+ " FROM MatHang, DMHang, ThuongHieu "
							+ " WHERE MatHang.MaDM=DMHang.MaDM and MatHang.MaTH=ThuongHieu.MaTH"
							+ " and MatHang.MaTH='"+maTH+"'";
				}else{
						sql=	"SELECT MaMH, TenMH, TenDM, TenTH, HSD, DonGia, DVT, SoLuong, MoTa "
								+ " FROM MatHang, DMHang, ThuongHieu "
								+ " WHERE MatHang.MaDM=DMHang.MaDM and MatHang.MaTH=ThuongHieu.MaTH"
								+ " and MatHang.MaTH='"+maTH+"' and MatHang.MaDM='"+maDM+"'";
				}
			}
		} else {
			sql=	"SELECT MaMH, TenMH, TenDM, TenTH, HSD, DonGia, DVT, SoLuong, MoTa "
					+ " FROM MatHang, DMHang, ThuongHieu "
					+ " WHERE MatHang.MaDM=DMHang.MaDM and MatHang.MaTH=ThuongHieu.MaTH"
					+ " and TenMH=N'"+tenMH+"'";
		}
		sql += " ORDER BY MaMH offset " + first + " rows fetch next " + last	+ " rows only";
		rs = null;
		try {
			stmt = connection.createStatement();
			rs = stmt.executeQuery(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		ArrayList<MatHang> list = new ArrayList<MatHang>();
		MatHang matHang;
		try {
			while(rs.next()){
				matHang = new MatHang();
				matHang.setMaMH(rs.getString("MaMH"));
				matHang.setTenMH(rs.getString("TenMH"));
				matHang.setTenDM(rs.getString("TenDM"));
				matHang.setTenTH(rs.getString("TenTH"));
				matHang.setHSD(rs.getString("HSD"));
				matHang.setDonGia(rs.getInt("DonGia"));
				matHang.setDVT(rs.getString("DVT"));
				matHang.setSoLuong(rs.getInt("SoLuong"));
				matHang.setMoTa(rs.getString("MoTa"));
				list.add(matHang);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

}

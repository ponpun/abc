package model.bean;

/**
 * ThuongHieu.java
 *
 * Version 1.0
 *
 * Date: 09-08-2017
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 09-08-2017           TuTNC           Create
 */
public class ThuongHieu {

    private String maTH;
    private String tenTH;
    
    /**
     * @return the maTH
     */
    public String getMaTH() {
        return maTH;
    }
    
    /**
     * @param maTH the maTH to set
     */
    public void setMaTH(String maTH) {
        this.maTH = maTH;
    }
    
    /**
     * @return the tenTH
     */
    public String getTenTH() {
        return tenTH;
    }
    
    /**
     * @param tenTH the tenTH to set
     */
    public void setTenTH(String tenTH) {
        this.tenTH = tenTH;
    }

}

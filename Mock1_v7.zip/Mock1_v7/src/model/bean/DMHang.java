package model.bean;

/**
 * DMHang.java
 *
 * Version 1.0
 *
 * Date: 09-08-2017
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 09-08-2017           TuTNC           Create
 */
public class DMHang {
    
    private String maDM;
    private String tenDM;
    
    /**
     * @return the maDM
     */
    public String getMaDM() {
        return maDM;
    }
    
    /**
     * @param maDM the maDM to set
     */
    public void setMaDM(String maDM) {
        this.maDM = maDM;
    }
    
    /**
     * @return the tenDM
     */
    public String getTenDM() {
        return tenDM;
    }
    
    /**
     * @param tenDM the tenDM to set
     */
    public void setTenDM(String tenDM) {
        this.tenDM = tenDM;
    }
    
    
}

package model.bean;

/**
 * MatHang.java
 *
 * Version 1.0
 *
 * Date: 09-08-2017
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 09-08-2017          TuTNC           Create
 */
public class MatHang {

    private String maMH;
    private String tenMH;
    private String maDM;
    private String tenDM;
    private String maTH;
    private String tenTH;
    private String dvt;
    private int soLuong;
    private String moTa;
    private String hsd;
    private int donGia;
    
    /**
     * @return the maMH
     */
    public String getMaMH() {
        return maMH;
    }
    
    /**
     * @param maMH the maMH to set
     */
    public void setMaMH(String maMH) {
        this.maMH = maMH;
    }
    
    /**
     * @return the tenMH
     */
    public String getTenMH() {
        return tenMH;
    }
    
    /**
     * @param tenMH the tenMH to set
     */
    public void setTenMH(String tenMH) {
        this.tenMH = tenMH;
    }
    
    /**
     * @return the maDM
     */
    public String getMaDM() {
        return maDM;
    }
    
    /**
     * @param maDM the maDM to set
     */
    public void setMaDM(String maDM) {
        this.maDM = maDM;
    }
    
    /**
     * @return the tenDM
     */
    public String getTenDM() {
        return tenDM;
    }
    
    /**
     * @param tenDM the tenDM to set
     */
    public void setTenDM(String tenDM) {
        this.tenDM = tenDM;
    }
    
    /**
     * @return the maTH
     */
    public String getMaTH() {
        return maTH;
    }
    
    /**
     * @param maTH the maTH to set
     */
    public void setMaTH(String maTH) {
        this.maTH = maTH;
    }
    
    /**
     * @return the tenTH
     */
    public String getTenTH() {
        return tenTH;
    }
    
    /**
     * @param tenTH the tenTH to set
     */
    public void setTenTH(String tenTH) {
        this.tenTH = tenTH;
    }
    
    /**
     * @return the dvt
     */
    public String getDVT() {
        return dvt;
    }
    
    /**
     * @param dvt the dvt to set
     */
    public void setDVT(String dvt) {
        this.dvt = dvt;
    }
    
    /**
     * @return the soLuong
     */
    public int getSoLuong() {
        return soLuong;
    }
    
    /**
     * @param soLuong the soLuong to set
     */
    public void setSoLuong(int soLuong) {
        this.soLuong = soLuong;
    }
    
    /**
     * @return the moTa
     */
    public String getMoTa() {
        return moTa;
    }
    
    /**
     * @param moTa the moTa to set
     */
    public void setMoTa(String moTa) {
        this.moTa = moTa;
    }
    
    /**
     * @return the hsd
     */
    public String getHSD() {
        return hsd;
    }
    
    /**
     * @param hsd the hsd to set
     */
    public void setHSD(String hsd) {
        this.hsd = hsd;
    }
    
    /**
     * @return the donGia
     */
    public int getDonGia() {
        return donGia;
    }
    
    /**
     * @param donGia the donGia to set
     */
    public void setDonGia(int donGia) {
        this.donGia = donGia;
    }

    
}

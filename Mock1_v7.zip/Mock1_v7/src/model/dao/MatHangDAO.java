package model.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import model.bean.DMHang;
import model.bean.MatHang;
import model.bean.ThuongHieu;

/**
 * MatHangDAO.java
 *
 * Version 1.0
 *
 * Date: 09-08-2017
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 09-08-2017           TuTNC           Create
 */
public class MatHangDAO {

    Statement stmt;
    PreparedStatement pstm;
    CallableStatement calstmt;
    ResultSet rs;

    BaseDAO baseDAO = new BaseDAO();
    Connection connection;
    
    /**
     * get ds thuong hieu
     * @return list ThuongHieu
     * @throws SQLException
     */
    public ArrayList<ThuongHieu> getListThuongHieu() throws SQLException {
        connection = baseDAO.getConnection();
        
        String sql=	"SELECT MaTH, TenTH FROM ThuongHieu ORDER BY TenTH";
        rs = null;
        ArrayList<ThuongHieu> list = new ArrayList<ThuongHieu>();
        ThuongHieu thuongHieu;
        
        try {
            stmt = connection.createStatement();
            rs = stmt.executeQuery(sql);
            
            while(rs.next()){
                thuongHieu = new ThuongHieu();
                thuongHieu.setMaTH(rs.getString("MaTH"));
                thuongHieu.setTenTH(rs.getString("TenTH"));
                list.add(thuongHieu);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            connection.close();
        }
        
        return list;
    }

    /**
     * get ds danh muc
     * @return list DMHang
     * @throws SQLException
     */
    public ArrayList<DMHang> getListDMHang() throws SQLException {
        connection = baseDAO.getConnection();
        
        String sql=	"SELECT MaDM, TenDM FROM DMHang ORDER BY TenDM";
        rs = null;
        ArrayList<DMHang> list = new ArrayList<DMHang>();
        DMHang dmHang;
        
        try {
            stmt = connection.createStatement();
            rs = stmt.executeQuery(sql);
            
            while(rs.next()){
                dmHang = new DMHang();
                
                dmHang.setMaDM(rs.getString("MaDM"));
                dmHang.setTenDM(rs.getString("TenDM"));
                
                list.add(dmHang);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            connection.close();
        }
        
        return list;
    }

    /**
     * them mat hang
     * @param maMH
     * @param tenMH
     * @param maTH
     * @param maDM
     * @param hSD
     * @param donGia
     * @param dVT
     * @param soLuong
     * @param moTa
     * @throws SQLException
     */
    public void addMatHang(String maMH, String tenMH, String maTH, String maDM, 
            String hSD, int donGia, String dVT, int soLuong, String moTa ) throws SQLException{
        connection = baseDAO.getConnection();
        
        String sql=	String.format(" INSERT INTO MatHang(MaMH, TenMH, MaTH, MaDM, HSD, DonGia, DVT, SoLuong, MoTa) "
                  + " VALUES ( '%s',N'%s','%s','%s',convert(datetime,'%s',103),'%s',N'%s','%s',N'%s' )", maMH.trim(), tenMH.trim(), 
                      maTH.trim(), maDM.trim(), hSD, donGia, dVT.trim(), soLuong,  moTa.trim());
        
        try {
            stmt = connection.createStatement();
            stmt.executeUpdate(sql);
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            connection.close();
        }
    }
    
    /**
     * lay ma mat hang
     * @return maMH
     * @throws SQLException
     */
    public String viewMaMH() throws SQLException{
        connection = baseDAO.getConnection();
        String maMH = null;
        
        try {
            calstmt = connection.prepareCall("{call SP_HIENTHIMaMH}");
            rs = calstmt.executeQuery();
            
            if (rs.next()){
                maMH = rs.getString("MaMH");
            } else {
                
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            connection.close();
        }
        
        return maMH;
    }

    /**
     * dem so ban ghi
     * @return count
     * @throws SQLException
     */
    public int countRows() throws SQLException {
        connection = baseDAO.getConnection();
        
        String sql = "SELECT count(MaMH) FROM MatHang";
        int count = 0;
        
        try {
            stmt = connection.createStatement();
            rs = stmt.executeQuery(sql);
            
            while (rs.next()) {
                count += rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            connection.close();
        }
        
        return count;
    }

    /**
     * get list mat hang theo phan trang
     * @param first
     * @param last
     * @return list MatHang
     * @throws SQLException
     */
    public ArrayList<MatHang> getListMatHang(int first, int last) throws SQLException {
        connection = baseDAO.getConnection();
        
        String sql = "SELECT MaMH, TenMH, TenDM, TenTH, FORMAT(HSD,'dd/MM/yyyy') as HSD, DonGia, DVT, SoLuong, MoTa "
                + " FROM MatHang, DMHang, ThuongHieu "
                + " WHERE MatHang.MaDM = DMHang.MaDM and MatHang.MaTH = ThuongHieu.MaTH "
                + " ORDER BY MaMH offset " + first + " rows fetch next " + last	+ " rows only";
        rs = null;
        ArrayList<MatHang> list = new ArrayList<MatHang>();
        MatHang matHang;
        
        try {
            stmt = connection.createStatement();
            rs = stmt.executeQuery(sql);
            
            while(rs.next()){
                matHang = new MatHang();
                
                matHang.setMaMH(rs.getString("MaMH"));
                matHang.setTenMH(rs.getString("TenMH"));
                matHang.setTenDM(rs.getString("TenDM"));
                matHang.setTenTH(rs.getString("TenTH"));
                matHang.setHSD(rs.getString("HSD"));
                matHang.setDonGia(rs.getInt("DonGia"));
                matHang.setDVT(rs.getString("DVT"));
                matHang.setSoLuong(rs.getInt("SoLuong"));
                matHang.setMoTa(rs.getString("MoTa"));
                
                list.add(matHang);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            connection.close();
        }
        
        return list;
    }

    /**
     * dem so ban ghi thoa man dieu kien
     * @param tenMH
     * @param maTH
     * @param maDM
     * @return count
     * @throws SQLException
     */
    public int countRows(String tenMH, String maTH, String maDM) throws SQLException {
        connection = baseDAO.getConnection();
        
        String sql;
        if (tenMH == null || tenMH.length() == 0) {
            if (maTH == ""  && maDM != "") {
                sql = " SELECT count(MaMH) "
                    + " FROM MatHang, DMHang, ThuongHieu "
                    + " WHERE MatHang.MaDM = DMHang.MaDM and MatHang.MaTH = ThuongHieu.MaTH"
                    + " and MatHang.MaDM = '" + maDM + "'";
            } else {
                if (maTH != "" && maDM == "") {
                    sql = " SELECT count(MaMH) "
                        + " FROM MatHang, DMHang, ThuongHieu "
                        + " WHERE MatHang.MaDM = DMHang.MaDM and MatHang.MaTH = ThuongHieu.MaTH"
                        + " and MatHang.MaTH = '" + maTH + "'";
                } else {
                    sql = " SELECT count(MaMH) "
                            + " FROM MatHang, DMHang, ThuongHieu "
                            + " WHERE MatHang.MaDM = DMHang.MaDM and MatHang.MaTH = ThuongHieu.MaTH"
                            + " and MatHang.MaTH = '" + maTH + "' and MatHang.MaDM = '" + maDM + "'";
                }
            }
        } else {
            sql = " SELECT count(MaMH) "
                + " FROM MatHang, DMHang, ThuongHieu "
                + " WHERE MatHang.MaDM=DMHang.MaDM and MatHang.MaTH=ThuongHieu.MaTH"
                + " and TenMH like N'%" + tenMH + "%'";
        }
        
        int count = 0;
        
        try {
            stmt = connection.createStatement();
            rs = stmt.executeQuery(sql);
            
            while (rs.next()) {
                count += rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            connection.close();
        }
        
        return count;
    }

    /**
     * get ds mat hang thoan man dieu kien co phan thang
     * @param first
     * @param last
     * @param tenMH
     * @param maTH
     * @param maDM
     * @return list MatHang
     * @throws SQLException
     */
    public ArrayList<MatHang> getListMatHang(int first, int last, String tenMH, String maTH, String maDM) throws SQLException {
        connection = baseDAO.getConnection();
        String sql;
        if (tenMH == null || tenMH.length() == 0) {
            if (maTH == ""  && maDM != "") {
                sql = " SELECT MaMH, TenMH, TenDM, TenTH, FORMAT(HSD,'dd/MM/yyyy') as HSD, DonGia, DVT, SoLuong, MoTa "
                    + " FROM MatHang, DMHang, ThuongHieu "
                    + " WHERE MatHang.MaDM = DMHang.MaDM and MatHang.MaTH = ThuongHieu.MaTH"
                    + " and MatHang.MaDM = '" + maDM + "'";
            } else {
                if (maTH != "" && maDM == "") {
                    sql = " SELECT MaMH, TenMH, TenDM, TenTH, FORMAT(HSD,'dd/MM/yyyy') as HSD, DonGia, DVT, SoLuong, MoTa "
                        + " FROM MatHang, DMHang, ThuongHieu "
                        + " WHERE MatHang.MaDM = DMHang.MaDM and MatHang.MaTH = ThuongHieu.MaTH"
                        + " and MatHang.MaTH = '" + maTH + "'";
                } else {
                    sql = " SELECT MaMH, TenMH, TenDM, TenTH, FORMAT(HSD,'dd/MM/yyyy') as HSD, DonGia, DVT, SoLuong, MoTa "
                            + " FROM MatHang, DMHang, ThuongHieu "
                            + " WHERE MatHang.MaDM = DMHang.MaDM and MatHang.MaTH = ThuongHieu.MaTH"
                            + " and MatHang.MaTH = '" + maTH + "' and MatHang.MaDM = '" + maDM + "'";
                }
            }
        } else {
            sql = " SELECT MaMH, TenMH, TenDM, TenTH, FORMAT(HSD,'dd/MM/yyyy') as HSD, DonGia, DVT, SoLuong, MoTa "
                + " FROM MatHang, DMHang, ThuongHieu "
                + " WHERE MatHang.MaDM=DMHang.MaDM and MatHang.MaTH=ThuongHieu.MaTH"
                + " and TenMH like N'%" + tenMH + "%'";
        }
        sql += " ORDER BY MaMH offset " + first + " rows fetch next " + last + " rows only";
        rs = null;
        ArrayList<MatHang> list = new ArrayList<MatHang>();
        MatHang matHang;
        
        try {
            stmt = connection.createStatement();
            rs = stmt.executeQuery(sql);
            
            while(rs.next()){
                matHang = new MatHang();
                
                matHang.setMaMH(rs.getString("MaMH"));
                matHang.setTenMH(rs.getString("TenMH"));
                matHang.setTenDM(rs.getString("TenDM"));
                matHang.setTenTH(rs.getString("TenTH"));
                matHang.setHSD(rs.getString("HSD"));
                matHang.setDonGia(rs.getInt("DonGia"));
                matHang.setDVT(rs.getString("DVT"));
                matHang.setSoLuong(rs.getInt("SoLuong"));
                matHang.setMoTa(rs.getString("MoTa"));
                
                list.add(matHang);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            connection.close();
        }

        return list;
    }

}

package model.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * BaseDAO.java
 *
 * Version 1.0
 *
 * Date: Aug 9, 2017
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * Aug 9, 2017          TuTNC           Create
 */
public class BaseDAO {
	String url = "jdbc:sqlserver://localhost:1433;databaseName=NhapXuatKho";
	String userName = "sa";
	String password = "Abcde12345";
	Connection connection;
	
	/**
	 * @return connection
	 */
	Connection getConnection(){
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			connection = DriverManager.getConnection(url, userName, password);
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return connection;
	}

}

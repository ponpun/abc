package model.bo;

import java.sql.SQLException;
import java.util.ArrayList;

import model.bean.DMHang;
import model.bean.MatHang;
import model.bean.ThuongHieu;
import model.dao.MatHangDAO;

/**
 * MatHangBO.java
 *
 * Version 1.0
 *
 * Date: 09-08-2017
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 09-08-2017           TuTNC           Create
 */
public class MatHangBO {

    MatHangDAO matHangDAO = new MatHangDAO();

    /**
     * get ds thuong hieu
     * @return list ThuongHieu
     * @throws SQLException
     */
    public ArrayList<ThuongHieu> getListThuongHieu() throws SQLException {
        return matHangDAO.getListThuongHieu();
    }

    /**
     * get ds danh muc
     * @return list DMHang
     * @throws SQLException
     */
    public ArrayList<DMHang> getListDMHang() throws SQLException {
        return matHangDAO.getListDMHang();
    }

     /**
     * them mat hang
     * @param maMH
     * @param tenMH
     * @param maTH
     * @param maDM
     * @param hSD
     * @param donGia
     * @param dVT
     * @param soLuong
     * @param moTa
     * @throws SQLException
     */
    public void addMatHang(String maMH, String tenMH, String maTH, String maDM, 
            String hSD, int donGia, String dVT, int soLuong, String moTa ) throws SQLException{
        matHangDAO.addMatHang(maMH, tenMH, maTH, maDM, hSD, donGia, dVT, soLuong, moTa);
    }

    /**
     * get ma mat hang
     * @return maMH
     * @throws SQLException
     */
    public String viewMaMH() throws SQLException{
        return matHangDAO.viewMaMH();
    }

    /**
     * dem so ban ghi
     * @return count
     * @throws SQLException
     */
    public int countRows() throws SQLException {
        return matHangDAO.countRows();
    }

    /**
     * get ds mat hang theo phan trang
     * @param first
     * @param last
     * @return list MatHang
     * @throws SQLException
     */
    public ArrayList<MatHang> getListMatHang(int first, int last) throws SQLException {
        return matHangDAO.getListMatHang(first, last);
    }

    /**
     * dem so ban ghi thoa man dieu kien
     * @param tenMH
     * @param maTH
     * @param maDM
     * @return count
     * @throws SQLException
     */
    public int countRows(String tenMH, String maTH, String maDM) throws SQLException {
        return matHangDAO.countRows(tenMH, maTH, maDM);
    }

    /**
     * get ds mat hang thoa man dieu kien theo phan trang
     * @param first
     * @param last
     * @param tenMH
     * @param maTH
     * @param maDM
     * @return list MatHang
     * @throws SQLException
     */
    public ArrayList<MatHang> getListMatHang(int first, int last, String tenMH, String maTH, String maDM) throws SQLException {
        return matHangDAO.getListMatHang(first, last, tenMH, maTH, maDM);
    }
}

package form;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import model.bean.DMHang;
import model.bean.MatHang;
import model.bean.ThuongHieu;

/**
 * MatHangForm.java
 *
 * Version 1.0
 *
 * Date: 09-08-2017
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * Aug 9, 2017          TuTNC           Create
 */
public class MatHangForm extends ActionForm{

    private String maMH;
    private String tenMH;
    private String maDM;
    private String tenDM;
    private String maTH;
    private String tenTH;
    private String DVT;
    private int soLuong;
    private String moTa;
    private String HSD;
    private int donGia;
    private String submit;

	private ArrayList<ThuongHieu> listThuongHieu;
	private ArrayList<DMHang> listDMHang;
	private MatHang matHang;
	
	/**
     * @return the maMH
     */
    public String getMaMH() {
        return maMH;
    }

    /**
     * @param maMH the maMH to set
     */
    public void setMaMH(String maMH) {
        this.maMH = maMH;
    }

    /**
     * @return the tenMH
     */
    public String getTenMH() {
        return tenMH;
    }

    /**
     * @param tenMH the tenMH to set
     */
    public void setTenMH(String tenMH) {
        this.tenMH = tenMH;
    }

    /**
     * @return the maDM
     */
    public String getMaDM() {
        return maDM;
    }

    /**
     * @param maDM the maDM to set
     */
    public void setMaDM(String maDM) {
        this.maDM = maDM;
    }

    /**
     * @return the tenDM
     */
    public String getTenDM() {
        return tenDM;
    }

    /**
     * @param tenDM the tenDM to set
     */
    public void setTenDM(String tenDM) {
        this.tenDM = tenDM;
    }

    /**
     * @return the maTH
     */
    public String getMaTH() {
        return maTH;
    }

    /**
     * @param maTH the maTH to set
     */
    public void setMaTH(String maTH) {
        this.maTH = maTH;
    }

    /**
     * @return the tenTH
     */
    public String getTenTH() {
        return tenTH;
    }

    /**
     * @param tenTH the tenTH to set
     */
    public void setTenTH(String tenTH) {
        this.tenTH = tenTH;
    }

    /**
     * @return the dVT
     */
    public String getDVT() {
        return DVT;
    }

    /**
     * @param dVT the dVT to set
     */
    public void setDVT(String dVT) {
        DVT = dVT;
    }

    /**
     * @return the soLuong
     */
    public int getSoLuong() {
        return soLuong;
    }

    /**
     * @param soLuong the soLuong to set
     */
    public void setSoLuong(int soLuong) {
        this.soLuong = soLuong;
    }

    /**
     * @return the moTa
     */
    public String getMoTa() {
        return moTa;
    }

    /**
     * @param moTa the moTa to set
     */
    public void setMoTa(String moTa) {
        this.moTa = moTa;
    }

    /**
     * @return the hSD
     */
    public String getHSD() {
        return HSD;
    }

    /**
     * @param hSD the hSD to set
     */
    public void setHSD(String hSD) {
        HSD = hSD;
    }

    /**
     * @return the donGia
     */
    public int getDonGia() {
        return donGia;
    }

    /**
     * @param donGia the donGia to set
     */
    public void setDonGia(int donGia) {
        this.donGia = donGia;
    }

    /**
     * @return the submit
     */
    public String getSubmit() {
        return submit;
    }

    /**
     * @param submit the submit to set
     */
    public void setSubmit(String submit) {
        this.submit = submit;
    }

    /**
     * @return the listThuongHieu
     */
    public ArrayList<ThuongHieu> getListThuongHieu() {
        return listThuongHieu;
    }

    /**
     * @param listThuongHieu the listThuongHieu to set
     */
    public void setListThuongHieu(ArrayList<ThuongHieu> listThuongHieu) {
        this.listThuongHieu = listThuongHieu;
    }

    /**
     * @return the listDMHang
     */
    public ArrayList<DMHang> getListDMHang() {
        return listDMHang;
    }

    /**
     * @param listDMHang the listDMHang to set
     */
    public void setListDMHang(ArrayList<DMHang> listDMHang) {
        this.listDMHang = listDMHang;
    }

    /**
     * @return the matHang
     */
    public MatHang getMatHang() {
        return matHang;
    }

    /**
     * @param matHang the matHang to set
     */
    public void setMatHang(MatHang matHang) {
        this.matHang = matHang;
    }

    public void reset(ActionMapping mapping, HttpServletRequest request) {
        try {
            request.setCharacterEncoding("UTF-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
    }

}

package form;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import model.bean.DMHang;
import model.bean.MatHang;
import model.bean.ThuongHieu;

/**
 * ListMatHangForm.java
 *
 * Version 1.0
 *
 * Date: 09-08-2017
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 09-08-2017           TuTNC           Create
 */
public class ListMatHangForm extends ActionForm{

	private String tenMH;
	private String maDM;
	private String maTH;
	
	private int page;
	private int totalPages;
	
	private ArrayList<MatHang> listMatHang;
	private ArrayList<ThuongHieu> listThuongHieu;
	private ArrayList<DMHang> listDMHang;
	
	
	
	/**
     * @return the tenMH
     */
    public String getTenMH() {
        return tenMH;
    }

    /**
     * @param tenMH the tenMH to set
     */
    public void setTenMH(String tenMH) {
        this.tenMH = tenMH;
    }

    /**
     * @return the maDM
     */
    public String getMaDM() {
        return maDM;
    }

    /**
     * @param maDM the maDM to set
     */
    public void setMaDM(String maDM) {
        this.maDM = maDM;
    }

    /**
     * @return the maTH
     */
    public String getMaTH() {
        return maTH;
    }

    /**
     * @param maTH the maTH to set
     */
    public void setMaTH(String maTH) {
        this.maTH = maTH;
    }

    /**
     * @return the page
     */
    public int getPage() {
        return page;
    }

    /**
     * @param page the page to set
     */
    public void setPage(int page) {
        this.page = page;
    }

    /**
     * @return the totalPages
     */
    public int getTotalPages() {
        return totalPages;
    }

    /**
     * @param totalPages the totalPages to set
     */
    public void setTotalPages(int totalPages) {
        this.totalPages = totalPages;
    }

    /**
     * @return the listMatHang
     */
    public ArrayList<MatHang> getListMatHang() {
        return listMatHang;
    }

    /**
     * @param listMatHang the listMatHang to set
     */
    public void setListMatHang(ArrayList<MatHang> listMatHang) {
        this.listMatHang = listMatHang;
    }

    /**
     * @return the listThuongHieu
     */
    public ArrayList<ThuongHieu> getListThuongHieu() {
        return listThuongHieu;
    }

    /**
     * @param listThuongHieu the listThuongHieu to set
     */
    public void setListThuongHieu(ArrayList<ThuongHieu> listThuongHieu) {
        this.listThuongHieu = listThuongHieu;
    }

    /**
     * @return the listDMHang
     */
    public ArrayList<DMHang> getListDMHang() {
        return listDMHang;
    }

    /**
     * @param listDMHang the listDMHang to set
     */
    public void setListDMHang(ArrayList<DMHang> listDMHang) {
        this.listDMHang = listDMHang;
    }

    public void reset(ActionMapping mapping, HttpServletRequest request) {
		try {
			request.setCharacterEncoding("UTF-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
	}
	
}

package action;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import form.ListMatHangForm;
import model.bean.MatHang;
import model.bo.MatHangBO;

/**
 * PhanTrangListMatHangAction.java
 *
 * Version 1.0
 *
 * Date: 09-08-2017
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 09-08-2017           TuTNC           Create
 */
public class PhanTrangListMatHangAction extends Action{
    int first = 0;
    int pages = 1;
    int totalPerPage = 10;
    int totalPages = 0;
    MatHangBO matHangBO = new MatHangBO();
    
    @Override
    public ActionForward execute(ActionMapping mapping, ActionForm form,
            HttpServletRequest request, HttpServletResponse response)
                    throws Exception {
        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("UTF-8");
            
        ListMatHangForm listMatHangForm = (ListMatHangForm) form;
        
        //lay page hien tai
        pages = listMatHangForm.getPage();
        
        //lay ds mat hang
        ArrayList<MatHang> listMatHang;
        String tenMH = listMatHangForm.getTenMH();
        listMatHangForm.setTenMH(tenMH);
        
        String maTH = listMatHangForm.getMaTH();
        String maDM = listMatHangForm.getMaDM();
        if((maTH == null || maTH.length() == 0) && (maDM == null || maDM.length() == 0)
                && (tenMH == null || tenMH.length() == 0)){		
            pagination(matHangBO.countRows());
            //get ds mat hang theo phan trang
            listMatHang = matHangBO.getListMatHang(first, totalPerPage);
        } else {
            pagination(matHangBO.countRows(tenMH, maTH, maDM));
            //get ds mat hang thoa man dieu kien theo phan trang
            listMatHang = matHangBO.getListMatHang(first, totalPerPage, tenMH, maTH, maDM);
        }
        listMatHangForm.setListMatHang(listMatHang);
        
        String strResult = "";
        for (MatHang mh : listMatHang) {
            strResult += "<tr class=\"TR\">" 
                    + "<td class=\"td-text-center\">"
                    + "<span class=\"glyphicon glyphicon-plus-sign blue trigger\"></span></td>"
                    + "<td>" + mh.getMaMH() + "</td>" 
                    + "<td>" + mh.getTenMH() + "</td>" 
                    + "<td class=\"td-text-right\">" + mh.getDonGia() + "</td>" 
                    + "<td class=\"td-text-center\">"
                    + "<span class=\"glyphicon glyphicon-pencil blue\"></span></td>"
                    + "<td class=\"td-text-center\">"
                    + "<span class=\"glyphicon glyphicon-trash blue\"></span></td>"
                    + "</tr>"
                    + "<tr class=\"details\">"
                    + "<td></td>"
                    + "<td colspan=\"5\">"
                    + "<table>"
                    + "<tr>"		
                    + "<td style=\"width: 70px;\">Tên DM:</td>"
                    + "<td style=\"width: 200px\">" + mh.getTenDM() + "</td>"
                    + "<td style=\"width: 50px;\"></td>"
                    + "<td style=\"width: 80px;\">HSD:</td>"
                    + "<td style=\"width: 100px\">" + mh.getHSD() + "</td>"
                    + "<td style=\"width: 50px;\"></td>"
                    + "<td style=\"width: 70px;\">ĐVT:</td>"
                    + "<td style=\"width: 300px\">" + mh.getDVT() + "</td>"
                    + "</tr>"
                    + "<tr>"
                    + "<td>Tên TH:</td>"
                    + "<td>" + mh.getTenTH() + "</td>"
                    + "<td></td>"
                    + "<td>Số lượng:</td>"
                    + "<td>" + mh.getSoLuong() + "</td>"
                    + "<td></td>"
                    + "<td>Mô tả:</td>"
                    + "<td>" + mh.getMoTa() + "</td>"
                    + "</tr>"	
                    + "<tr>"
                    + "<td colspan=\"5\" class=\"td1\">"
                    + "<button type=\"button\" class=\"btn btn-default\" style=\"width: 100px; height:35px; margin-right: 10px;\">Chỉnh sửa</button>"
                    + "<button type=\"button\" class=\"btn btn-default\" style=\"width: 70px; height:35px\">Xóa</button>"
                    + "</td>"
                    + "</tr>"
                    + "</tr>"
                    + "</table>"	
                    + "</td>"
                    + "</tr>";
        }
        response.getWriter().println(strResult);
        listMatHangForm.setTotalPages(totalPages);
        return null;
    }

    // phan trang
    private void pagination(int total) {
        //tong so pages
        if (total % totalPerPage != 0 || total == 0){
            totalPages = total / totalPerPage + 1;
        } else {
            totalPages = total / totalPerPage;
        }
        
        //giới hạn pages trong khoảng 1 đến totalPages
        if (pages > totalPages){
            pages = totalPages;
        } else if (pages < 1) {
            pages = 1;
        }
        
        //tìm first
        first = (pages - 1) * totalPerPage;
    }
}

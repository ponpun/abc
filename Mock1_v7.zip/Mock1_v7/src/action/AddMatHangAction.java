package action;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import form.MatHangForm;
import model.bean.DMHang;
import model.bean.ThuongHieu;
import model.bo.MatHangBO;

/**
 * AddMatHangAction.java
 *
 * Version 1.0
 *
 * Date: 09-08-2017
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 09-08-2017           TuTNC           Create
 */
public class AddMatHangAction extends Action{
    @Override
    public ActionForward execute(ActionMapping mapping, ActionForm form,
            HttpServletRequest request, HttpServletResponse response) throws Exception {
        request.setCharacterEncoding("UTF-8");
        
        MatHangForm matHangForm = (MatHangForm) form;
        MatHangBO matHangBO = new MatHangBO();
        
        //lay ds thuong hieu
        ArrayList<ThuongHieu> listThuongHieu = matHangBO.getListThuongHieu();
        matHangForm.setListThuongHieu(listThuongHieu);
        
        //lay ds danh muc
        ArrayList<DMHang> listDMHang = matHangBO.getListDMHang();
        matHangForm.setListDMHang(listDMHang);
        
        //lay ma mat hang
        matHangForm.setMaMH(matHangBO.viewMaMH());
        
        
        if("Xác nhận".equals(matHangForm.getSubmit())){                  //nhan nut Xac nhan o trang Them mat hang
            String maMH = matHangForm.getMaMH();
            String tenMH = matHangForm.getTenMH();
            String maTH= matHangForm.getMaTH();
            String maDM = matHangForm.getMaDM();
            String hSD = matHangForm.getHSD();
            String dVT = matHangForm.getDVT();
            String moTa= matHangForm.getMoTa();
            int donGia = matHangForm.getDonGia();
            int soLuong = matHangForm.getSoLuong();
            
            matHangBO.addMatHang(maMH, tenMH, maTH, maDM, hSD, donGia, dVT, soLuong, moTa);
            return mapping.findForward("themMHxong");
        } else {                                        //chuyen sang trang Them mat hang
            return mapping.findForward("themMH");
        }
        
    }
}

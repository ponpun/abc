package form;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import model.bean.Cities;
import model.bean.Countries;
import model.bean.Institutions;
import model.bean.States;
import model.bean.StudentReg;
import model.bean.Systems;

/**
 * StudentRegForm.java
 *
 * Version 1.0
 *
 * Date: 23-08-2017
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 23-08-2017           TuTNC           Create
 */
public class StudentRegForm extends ActionForm {
    private String firstName;
    private String lastName;
    private String title;
    private String institutionCode;
    private String institutionName;
    private double studentCode;
    private double phone;
    private String email;
    private String address;
    private String cityCode;
    private String cityName;
    private String stateCode;
    private String stateName;
    private String zipcode;
    private String countryCode;
    private String countryName;
    private String systemName;
    private String timePurchase;
    private String place;
    private String comment;
    
    private ArrayList<StudentReg> listStudentReg;
    private ArrayList<Cities> listCitites;
    private ArrayList<States> listStates;
    private ArrayList<Countries> listCountries;
    private ArrayList<Systems> listSystems;
    private ArrayList<Institutions> listInstitutions;
    private ArrayList<Systems> listSystemName;
    private ArrayList<Systems> listTimePurchase;
    
    private String submit;
    
    /**
     * @return the firstName
     */
    public String getFirstName() {
        return firstName;
    }
    
    /**
     * @param firstName the firstName to set
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    
    /**
     * @return the lastName
     */
    public String getLastName() {
        return lastName;
    }
    
    /**
     * @param lastName the lastName to set
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    
    /**
     * @return the title
     */
    public String getTitle() {
        return title;
    }
    
    /**
     * @param title the title to set
     */
    public void setTitle(String title) {
        this.title = title;
    }
    
    /**
     * @return the institutionCode
     */
    public String getInstitutionCode() {
        return institutionCode;
    }
    
    /**
     * @param institutionCode the institutionCode to set
     */
    public void setInstitutionCode(String institutionCode) {
        this.institutionCode = institutionCode;
    }
    
    /**
     * @return the institutionName
     */
    public String getInstitutionName() {
        return institutionName;
    }
    
    /**
     * @param institutionName the institutionName to set
     */
    public void setInstitutionName(String institutionName) {
        this.institutionName = institutionName;
    }
    
    /**
     * @return the studentCode
     */
    public double getStudentCode() {
        return studentCode;
    }
    
    /**
     * @param studentCode the studentCode to set
     */
    public void setStudentCode(double studentCode) {
        this.studentCode = studentCode;
    }
    
    /**
     * @return the phone
     */
    public double getPhone() {
        return phone;
    }
    
    /**
     * @param phone the phone to set
     */
    public void setPhone(double phone) {
        this.phone = phone;
    }
    
    /**
     * @return the email
     */
    public String getEmail() {
        return email;
    }
    
    /**
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }
    
    /**
     * @return the address
     */
    public String getAddress() {
        return address;
    }
    
    /**
     * @param address the address to set
     */
    public void setAddress(String address) {
        this.address = address;
    }
    
    /**
     * @return the cityCode
     */
    public String getCityCode() {
        return cityCode;
    }
    
    /**
     * @param cityCode the cityCode to set
     */
    public void setCityCode(String cityCode) {
        this.cityCode = cityCode;
    }
    
    /**
     * @return the cityName
     */
    public String getCityName() {
        return cityName;
    }
    
    /**
     * @param cityName the cityName to set
     */
    public void setCityName(String cityName) {
        this.cityName = cityName;
    }
    
    /**
     * @return the stateCode
     */
    public String getStateCode() {
        return stateCode;
    }
    
    /**
     * @param stateCode the stateCode to set
     */
    public void setStateCode(String stateCode) {
        this.stateCode = stateCode;
    }
    
    /**
     * @return the stateName
     */
    public String getStateName() {
        return stateName;
    }
    
    /**
     * @param stateName the stateName to set
     */
    public void setStateName(String stateName) {
        this.stateName = stateName;
    }
    
    /**
     * @return the zipcode
     */
    public String getZipcode() {
        return zipcode;
    }
    
    /**
     * @param zipcode the zipcode to set
     */
    public void setZipcode(String zipcode) {
        this.zipcode = zipcode;
    }
    
    /**
     * @return the countryCode
     */
    public String getCountryCode() {
        return countryCode;
    }
    
    /**
     * @param countryCode the countryCode to set
     */
    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }
    
    /**
     * @return the countryName
     */
    public String getCountryName() {
        return countryName;
    }
    
    /**
     * @param countryName the countryName to set
     */
    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }
    
    /**
     * @return the systemName
     */
    public String getSystemName() {
        return systemName;
    }
    
    /**
     * @param systemName the systemName to set
     */
    public void setSystemName(String systemName) {
        this.systemName = systemName;
    }
    
    /**
     * @return the timePurchase
     */
    public String getTimePurchase() {
        return timePurchase;
    }
    
    /**
     * @param timePurchase the timePurchase to set
     */
    public void setTimePurchase(String timePurchase) {
        this.timePurchase = timePurchase;
    }
    
    /**
     * @return the place
     */
    public String getPlace() {
        return place;
    }
    
    /**
     * @param place the place to set
     */
    public void setPlace(String place) {
        this.place = place;
    }
    
    /**
     * @return the comment
     */
    public String getComment() {
        return comment;
    }
    
    /**
     * @param comment the comment to set
     */
    public void setComment(String comment) {
        this.comment = comment;
    }
    
    /**
	 * @return the listStudentReg
	 */
	public ArrayList<StudentReg> getListStudentReg() {
		return listStudentReg;
	}

	/**
	 * @param listStudentReg the listStudentReg to set
	 */
	public void setListStudentReg(ArrayList<StudentReg> listStudentReg) {
		this.listStudentReg = listStudentReg;
	}

	/**
     * @return the listCitites
     */
    public ArrayList<Cities> getListCitites() {
        return listCitites;
    }
    
    /**
     * @param listCitites the listCitites to set
     */
    public void setListCitites(ArrayList<Cities> listCitites) {
        this.listCitites = listCitites;
    }
    
    /**
     * @return the listStates
     */
    public ArrayList<States> getListStates() {
        return listStates;
    }
    
    /**
     * @param listStates the listStates to set
     */
    public void setListStates(ArrayList<States> listStates) {
        this.listStates = listStates;
    }
    
    /**
     * @return the listCountries
     */
    public ArrayList<Countries> getListCountries() {
        return listCountries;
    }
    
    /**
     * @param listCountries the listCountries to set
     */
    public void setListCountries(ArrayList<Countries> listCountries) {
        this.listCountries = listCountries;
    }
    
    /**
     * @return the listSystems
     */
    public ArrayList<Systems> getListSystems() {
        return listSystems;
    }
    
    /**
     * @param listSystems the listSystems to set
     */
    public void setListSystems(ArrayList<Systems> listSystems) {
        this.listSystems = listSystems;
    }
    
    /**
     * @return the listInstitutions
     */
    public ArrayList<Institutions> getListInstitutions() {
        return listInstitutions;
    }
    
    /**
     * @param listInstitutions the listInstitutions to set
     */
    public void setListInstitutions(ArrayList<Institutions> listInstitutions) {
        this.listInstitutions = listInstitutions;
    }
    
    /**
     * @return the listSystemName
     */
    public ArrayList<Systems> getListSystemName() {
        return listSystemName;
    }

    /**
     * @param listSystemName2 the listSystemName to set
     */
    public void setListSystemName(ArrayList<Systems> listSystemName2) {
        this.listSystemName = listSystemName2;
    }

    /**
     * @return the listTimePurchase
     */
    public ArrayList<Systems> getListTimePurchase() {
        return listTimePurchase;
    }

    /**
     * @param listTimePurchase the listTimePurchase to set
     */
    public void setListTimePurchase(ArrayList<Systems> listTimePurchase) {
        this.listTimePurchase = listTimePurchase;
    }

    /**
     * @return the submit
     */
    public String getSubmit() {
        return submit;
    }

    /**
     * @param submit the submit to set
     */
    public void setSubmit(String submit) {
        this.submit = submit;
    }

    /* (non-Javadoc)
     * @see org.apache.struts.action.ActionForm#reset(org.apache.struts.action.ActionMapping, javax.servlet.http.HttpServletRequest)
     */
    public void reset(ActionMapping mapping, HttpServletRequest request) {
        try {
            request.setCharacterEncoding("UTF-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
    }
    
}

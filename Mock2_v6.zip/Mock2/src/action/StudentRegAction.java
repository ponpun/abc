package action;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import form.StudentRegForm;

import model.bean.Cities;
import model.bean.Countries;
import model.bean.Institutions;
import model.bean.States;
import model.bean.StudentReg;
import model.bean.Systems;

import model.bo.StudentRegBO;

/**
 * StudentRegAction.java
 *
 * Version 1.0
 *
 * Date: 23-08-2017
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 23-08-2017           TuTNC           Create
 */
public class StudentRegAction extends Action {
    @Override
    public ActionForward execute(ActionMapping mapping, ActionForm form,
            HttpServletRequest request, HttpServletResponse response) throws Exception {
        request.setCharacterEncoding("UTF-8");
        StudentRegForm studentRegForm = (StudentRegForm) form; 
        
        StudentRegBO studentRegBO = new StudentRegBO();
        
        ArrayList<Countries> listCountries = studentRegBO.getListCountries();
        studentRegForm.setListCountries(listCountries);
        
        ArrayList<Institutions> listInstitutions = studentRegBO.getListInstitutions();
        studentRegForm.setListInstitutions(listInstitutions);
        
        ArrayList<Systems> listSystemName = studentRegBO.getListSystemName();
        studentRegForm.setListSystemName(listSystemName);
               
        //nhan nut Xac nhan o trang Them
        if("登録(N)".equals(studentRegForm.getSubmit())){                  
            String firstName = studentRegForm.getFirstName();
            String lastName = studentRegForm.getLastName();
            String title = studentRegForm.getTitle();
            String institutionCode = studentRegForm.getInstitutionCode();
            double studentCode = studentRegForm.getStudentCode();
            double phone = studentRegForm.getPhone();
            String email = studentRegForm.getEmail();
            String address = studentRegForm.getAddress();
            String cityCode = studentRegForm.getCityCode();
            String stateCode = studentRegForm.getStateCode();
            String zipcode = studentRegForm.getZipcode();
            String countryCode = studentRegForm.getCountryCode();
            String systemName = studentRegForm.getSystemName();
            String timePurchase = studentRegForm.getTimePurchase();
            String place = studentRegForm.getPlace();
            String comment = studentRegForm.getComment();
            
            StudentReg studentReg = new StudentReg(firstName, lastName, title, institutionCode, studentCode,
                                    phone, email, address, cityCode, stateCode, zipcode, countryCode, systemName,
                                    timePurchase, place, comment);
            studentRegBO.reg(studentReg);
            
            //chuyen ve trang list
            return mapping.findForward("themxong");
        } else {
            String country = studentRegForm.getCountryName();
            
            //neu country khac null, lay ds city, state theo country
            if (country != null) {
                StringBuffer strResult1 = new StringBuffer("[");
                
                //lay ds city thuoc country
                ArrayList<Cities> listCitites = studentRegBO.getListCities(country); 
                for (Cities city : listCitites) {
                    strResult1.append("{\"id\":\"city\", \"cityCode\":\"" + city.getCode().trim() 
                                    + "\", \"cityName\":\"" + city.getName().trim() + "\"}, ");
                }
                
                //lay ds state thuoc country
                ArrayList<States> listStates = studentRegBO.getListStates(country);
                for (States state : listStates) {
                    strResult1.append("{\"id\":\"state\",\"stateCode\":\"" + state.getCode().trim() 
                                    + "\", \"stateName\":\"" + state.getName().trim() + "\"},");
                }
                
                strResult1.delete(strResult1.length() - 1, strResult1.length());
                strResult1.append("]");

                response.setContentType("text/html;charset=UTF-8");
                response.getWriter().println(strResult1);
                return null;
            }
            
            String system = studentRegForm.getSystemName();
            
            //neu system name khac null, lay ds time purchase theo system name
            if (system != null) {
                byte[] b = system.trim().getBytes("ISO-8859-1");
                system = new String(b, "UTF-8");
                                
                StringBuffer strResult1 = new StringBuffer("[");
                
                //lay ds time purchase co system name
                ArrayList<Systems> listTimePurchase = studentRegBO.getListTimePurchase(system);
                for (Systems system1 : listTimePurchase) {
                    strResult1.append("{\"time\":\"" + system1.getTimePurchase().trim() + "\"},");
                }
                
                strResult1.delete(strResult1.length() - 1, strResult1.length());
                strResult1.append("]");

                response.setContentType("text/html;charset=UTF-8");
                response.getWriter().println(strResult1);
                return null;
            }
            
            String email = studentRegForm.getEmail();
            
            //email ton tai
            if (email != null && studentRegBO.checkEmail(email)) {
                response.getWriter().println("co");
                return null;
            } else {
                //do nothing
            }
            
            String institutionCode = studentRegForm.getInstitutionCode();
            double studentCode = studentRegForm.getStudentCode();
            
            //institutionCode va studentCode ton tai
            if (institutionCode != null && studentCode != 0 && studentRegBO.checkStudent(studentCode, institutionCode)) {
                response.getWriter().println("co");
                return null;
            } else {
                //do nothing
            }
            
            //chuyen sang trang Them                                         
            return mapping.findForward("them");
        }
    }
}

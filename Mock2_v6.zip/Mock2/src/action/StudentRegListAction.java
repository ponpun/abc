package action;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import form.StudentRegForm;
import model.bean.StudentReg;
import model.bo.StudentRegBO;

/**
 * StudentRegListAction.java
 *
 * Version 1.0
 *
 * Date: 23-08-2017
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 23-08-2017           TuTNC           Create
 */
public class StudentRegListAction extends Action {
    @Override
    public ActionForward execute(ActionMapping mapping, ActionForm form,
            HttpServletRequest request, HttpServletResponse response) throws Exception {
        request.setCharacterEncoding("UTF-8");
        StudentRegForm studentRegForm = (StudentRegForm) form; 
        
        StudentRegBO studentRegBO = new StudentRegBO();
        
        ArrayList<StudentReg> listStudentReg = studentRegBO.getListStudentReg();
        studentRegForm.setListStudentReg(listStudentReg);
        
        return mapping.findForward("listStudentReg");
    }

}

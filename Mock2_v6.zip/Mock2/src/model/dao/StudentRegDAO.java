package model.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import model.bean.Cities;
import model.bean.Countries;
import model.bean.Institutions;
import model.bean.States;
import model.bean.StudentReg;
import model.bean.Systems;

/**
 * StudentRegDAO.java
 *
 * Version 1.0
 *
 * Date: 23-08-2017
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 23-08-2017           TuTNC           Create
 */
public class StudentRegDAO {
    Statement statement;
    ResultSet resultSet;

    BaseDAO baseDAO = new BaseDAO();
    Connection connection;
    
    /**
     * @param country
     * @return listCities
     * @throws SQLException
     */
    public ArrayList<Cities> getListCities(String country) throws SQLException {
        connection = baseDAO.getConnection();
        
        String sql = "SELECT CODE, NAME FROM CITIES WHERE COUNTRY = N'" + country + "'";
        resultSet = null;
        ArrayList<Cities> listCities = new ArrayList<Cities>();
        Cities city;
        
        try {
            statement = connection.createStatement();
            resultSet = statement.executeQuery(sql);
            
            while (resultSet.next()) {
                city = new Cities();
                city.setCode(resultSet.getString("CODE").trim());
                city.setName(resultSet.getString("NAME").trim());
                listCities.add(city);
            }
            
        } catch (SQLException SQLExp) {
            SQLExp.printStackTrace();
            System.out.println("Ket noi loi");
        } finally {
            connection.close();
        }
        
        return listCities;
    }

    /**
     * @param country
     * @return listStates
     * @throws SQLException
     */
    public ArrayList<States> getListStates(String country) throws SQLException {
        connection = baseDAO.getConnection();
        
        String sql = "SELECT CODE, NAME FROM STATES WHERE COUNTRY = N'" + country + "'";
        resultSet = null;
        ArrayList<States> listStates = new ArrayList<States>();
        States state;
        
        try {
            statement = connection.createStatement();
            resultSet = statement.executeQuery(sql);
            
            while (resultSet.next()) {
                state = new States();
                state.setCode(resultSet.getString("CODE").trim());
                state.setName(resultSet.getString("NAME").trim());
                listStates.add(state);
            }
            
        } catch (SQLException SQLExp) {
            SQLExp.printStackTrace();
            System.out.println("Ket noi loi");
        } finally {
            connection.close();
        }
        
        return listStates;
    }

    /**
     * @return listCountries
     * @throws SQLException
     */
    public ArrayList<Countries> getListCountries() throws SQLException {
        connection = baseDAO.getConnection();
        
        String sql = "SELECT CODE, NAME FROM COUNTRIES";
        resultSet = null;
        ArrayList<Countries> listCountries = new ArrayList<Countries>();
        Countries country;
        
        try {
            statement = connection.createStatement();
            resultSet = statement.executeQuery(sql);
            
            while (resultSet.next()) {
                country = new Countries();
                country.setCode(resultSet.getString("CODE").trim());
                country.setName(resultSet.getString("NAME").trim());
                listCountries.add(country);
            }
            
        } catch (SQLException SQLExp) {
            SQLExp.printStackTrace();
            System.out.println("Ket noi loi");
        } finally {
            connection.close();
        }
        
        return listCountries;
    }

    /**
     * @return listSystems
     * @throws SQLException
     */
    public ArrayList<Systems> getListSystemName() throws SQLException {
        connection = baseDAO.getConnection();
        
        String sql = "SELECT DISTINCT SYSTEM_NAME FROM SYSTEMS";
        resultSet = null;
        ArrayList<Systems> listSystems = new ArrayList<Systems>();
        Systems systemName;
        
        try {
            statement = connection.createStatement();
            resultSet = statement.executeQuery(sql);
            
            while (resultSet.next()) {
                systemName = new Systems();
                systemName.setSystemName(resultSet.getString("SYSTEM_NAME").trim());
                listSystems.add(systemName);
            }
            
        } catch (SQLException SQLExp) {
            SQLExp.printStackTrace();
            System.out.println("Ket noi loi");
        } finally {
            connection.close();
        }
        
        return listSystems;
    }

    /**
     * @param systemName
     * @return listSystems
     * @throws SQLException
     */
    public ArrayList<Systems> getListTimePurchase(String systemName) throws SQLException {
        connection = baseDAO.getConnection();
        
        String sql = " SELECT DISTINCT TIME_PURCHASE FROM SYSTEMS WHERE SYSTEM_NAME = N'" + systemName + "'";
        resultSet = null;
        ArrayList<Systems> listSystems = new ArrayList<Systems>();
        Systems timePurchase;
        
        try {
            statement = connection.createStatement();
            resultSet = statement.executeQuery(sql);
            
            while (resultSet.next()) {
                timePurchase = new Systems();
                timePurchase.setTimePurchase(resultSet.getString("TIME_PURCHASE").trim());
                listSystems.add(timePurchase);
            }
            
        } catch (SQLException SQLExp) {
            SQLExp.printStackTrace();
            System.out.println("Ket noi loi");
        } finally {
            connection.close();
        }
        
        return listSystems;
    }

    /**
     * @param studentReg
     * @return boolean
     * @throws SQLException
     */
    public boolean reg(StudentReg studentReg) throws SQLException {
        connection = baseDAO.getConnection();
        
        String sql = String.format("INSERT INTO STUDENT_REG (FIRST_NAME, LAST_NAME, TITLE, INSTITUTION, STUDENT_CODE, "
                    + " PHONE, EMAIL, ADDRESS, CITY, STATE, ZIPCODE, COUNTRY, SYSTEM_NAME, TIME_PURCHASE, PLACE, COMMENT) "
                    + " VALUES (N'%s',N'%s',N'%s',N'%s','%f','%f',N'%s',N'%s',N'%s',N'%s',N'%s',N'%s',N'%s',N'%s',N'%s',N'%s')",
                    studentReg.getFirstName(), studentReg.getLastName(), studentReg.getTitle(), studentReg.getInstitutionCode(), 
                    studentReg.getStudentCode(), studentReg.getPhone(), studentReg.getEmail(), studentReg.getAddress(), 
                    studentReg.getCityCode(), studentReg.getStateCode(), studentReg.getZipcode(), studentReg.getCountryCode(), 
                    studentReg.getSystemName(), studentReg.getTimePurchase(), studentReg.getPlace(), studentReg.getComment());
                    
        try {
            statement = connection.createStatement();
            statement.executeUpdate(sql);
            return true;
        } catch (SQLException SQLExp) {
            SQLExp.printStackTrace();
            System.out.println("Ket noi loi");
            return false;
        } finally {
            connection.close();
        }
    }

    /**
     * @param email
     * @return boolean
     * @throws SQLException
     */
    public boolean checkEmail(String email) throws SQLException {
        connection = baseDAO.getConnection();
        
        String sql = "SELECT EMAIL FROM STUDENT_REG WHERE EMAIL = N'" + email + "'";
        resultSet = null;
        
        try {
            statement = connection.createStatement();
            resultSet = statement.executeQuery(sql);
            
            return resultSet.next();            
        } catch (SQLException SQLExp) {
            SQLExp.printStackTrace();
            System.out.println("Ket noi loi");
        } finally {
            connection.close();
        }
        return false;
    }

    /**
     * @param studentCode
     * @param institutionCode
     * @return boolean
     * @throws SQLException
     */
    public boolean checkStudent(double studentCode, String institutionCode) throws SQLException {
        connection = baseDAO.getConnection();
        
        String sql = "SELECT 1 FROM STUDENT_REG WHERE STUDENT_CODE = N'" + studentCode + "' AND INSTITUTION = N'" + institutionCode + "'";
        resultSet = null;
        
        try {
            statement = connection.createStatement();
            resultSet = statement.executeQuery(sql);
            
            return resultSet.next();
        } catch (SQLException SQLExp) {
            SQLExp.printStackTrace();
            System.out.println("Ket noi loi");
        } finally {
            connection.close();
        }
        return false;
    }

    /**
     * @return ArrayList<Institutions>
     * @throws SQLException
     */
    public ArrayList<Institutions> getListInstitutions() throws SQLException {
        connection = baseDAO.getConnection();
        
        String sql = "SELECT INSTITUTION_CODE, INSTITUTION_NAME FROM INSTITUTIONS";
        resultSet = null;
        ArrayList<Institutions> listInstitutions = new ArrayList<Institutions>();
        Institutions institutions;
        
        try {
            statement = connection.createStatement();
            resultSet = statement.executeQuery(sql);
            
            while (resultSet.next()) {
                institutions = new Institutions();
                institutions.setInstitutionCode(resultSet.getString("INSTITUTION_CODE").trim());
                institutions.setInstitutionName(resultSet.getString("INSTITUTION_NAME").trim());
                listInstitutions.add(institutions);
            }
            
        } catch (SQLException SQLExp) {
            SQLExp.printStackTrace();
            System.out.println("Ket noi loi");
        } finally {
            connection.close();
        }
        
        return listInstitutions;
    }

	public ArrayList<StudentReg> getListStudentReg() throws SQLException {
		connection = baseDAO.getConnection();
        
        String sql = "SELECT FIRST_NAME, LAST_NAME, TITLE, INSTITUTIONS.INSTITUTION_CODE, "
        			+ " INSTITUTIONS.INSTITUTION_NAME, STUDENT_CODE, PHONE, EMAIL, ADDRESS, CITIES.NAME AS CITIESNAME, "
        			+ " STATES.NAME AS STATESNAME, ZIPCODE, COUNTRIES.NAME AS COUNTRIESNAME, SYSTEM_NAME, TIME_PURCHASE, "
        			+ " PLACE, COMMENT FROM STUDENT_REG, CITIES, COUNTRIES, STATES, INSTITUTIONS "
        			+ " WHERE STUDENT_REG.CITY = CITIES.CODE AND STUDENT_REG.COUNTRY = COUNTRIES.CODE "
        			+ " AND STUDENT_REG.INSTITUTION = INSTITUTIONS.INSTITUTION_CODE AND STUDENT_REG.STATE = STATES.CODE";
        resultSet = null;
        ArrayList<StudentReg> listStudentReg = new ArrayList<StudentReg>();
        StudentReg studentReg;
        
        try {
            statement = connection.createStatement();
            resultSet = statement.executeQuery(sql);
            
            while (resultSet.next()) {
            	studentReg = new StudentReg();
            	studentReg.setFirstName(resultSet.getString("FIRST_NAME").trim());
            	studentReg.setLastName(resultSet.getString("LAST_NAME").trim());
            	studentReg.setTitle(resultSet.getString("TITLE").trim());
            	studentReg.setInstitutionCode(resultSet.getString("INSTITUTION_CODE").trim());
            	studentReg.setInstitutionName(resultSet.getString("INSTITUTION_NAME").trim());
                studentReg.setStudentCode(resultSet.getDouble("STUDENT_CODE"));
                studentReg.setPhone(resultSet.getDouble("PHONE"));
                studentReg.setEmail(resultSet.getString("EMAIL").trim());
                studentReg.setAddress(resultSet.getString("ADDRESS").trim());
                studentReg.setCityName(resultSet.getString("CITIESNAME").trim());
                studentReg.setStateName(resultSet.getString("STATESNAME").trim());
                studentReg.setZipcode(resultSet.getString("ZIPCODE").trim());
                studentReg.setCountryName(resultSet.getString("COUNTRIESNAME").trim());
                studentReg.setSystemName(resultSet.getString("SYSTEM_NAME").trim());
                studentReg.setTimePurchase(resultSet.getString("TIME_PURCHASE").trim());
                studentReg.setPlace(resultSet.getString("PLACE").trim());
                studentReg.setComment(resultSet.getString("COMMENT").trim());
                listStudentReg.add(studentReg);
            }
            
        } catch (SQLException SQLExp) {
            SQLExp.printStackTrace();
            System.out.println("Ket noi loi");
        } finally {
            connection.close();
        }
        
        return listStudentReg;
	}
}

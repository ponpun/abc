package model.bean;

/**
 * Countries.java
 *
 * Version 1.0
 *
 * Date: 23-08-2017
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 23-08-2017           TuTNC           Create
 */
public class Countries {
    private String code;
    private String name;
    private String continent;
    
    /**
     * @param code
     * @param name
     * @param continent
     */
    public Countries(String code, String name, String continent) {
        this.code = code;
        this.name = name;
        this.continent = continent;
    }

    /**
     * 
     */
    public Countries() {
        super();
        // TODO Auto-generated constructor stub
    }

    /**
     * @return the code
     */
    public String getCode() {
        return code;
    }
    
    /**
     * @param code the code to set
     */
    public void setCode(String code) {
        this.code = code;
    }
    
    /**
     * @return the name
     */
    public String getName() {
        return name;
    }
    
    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }
    
    /**
     * @return the continent
     */
    public String getContinent() {
        return continent;
    }
    
    /**
     * @param continent the continent to set
     */
    public void setContinent(String continent) {
        this.continent = continent;
    }
    
    
}

package test;

import static org.junit.Assert.*;

import java.sql.SQLException;
import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;

import model.bean.Cities;
import model.bean.Countries;
import model.bean.Institutions;
import model.bean.States;
import model.bean.StudentReg;
import model.bean.Systems;
import model.dao.StudentRegDAO;

/**
 * @author HCD-Fresher278
 *
 */
public class TestStudentRegDAO {
    protected StudentRegDAO studentRegDAO;
    protected Cities cities;
    protected Countries countries;
    protected Institutions institutions;
    protected States states;
    protected StudentReg studentReg;
    protected Systems systems;
    
    protected ArrayList<Cities> expectedListCities;
    protected ArrayList<Cities> actualListCities;
    
    protected ArrayList<States> expectedListStates;
    protected ArrayList<States> actualListStates;
    
    protected ArrayList<Countries> expectedListCountries;
    protected ArrayList<Countries> actualListCountries;
    
    protected ArrayList<Systems> expectedListSystems1;
    protected ArrayList<Systems> actualListSystems1;
    
    protected ArrayList<Systems> expectedListSystems2;
    protected ArrayList<Systems> actualListSystems2;
    
    /**
     * @throws java.lang.Exception
     */
    @Before
    public void setUp() throws Exception {
        studentRegDAO = new StudentRegDAO();
        
        expectedListCities = new ArrayList<Cities>();
        expectedListCities.add(new Cities("11",null,"アクワース"));
        expectedListCities.add(new Cities("13",null,"ニューヨーク"));
        expectedListCities.add(new Cities("15",null,"ロサンゼルス"));
        expectedListCities.add(new Cities("7",null,"マウンテンビュー"));
        
        expectedListStates = new ArrayList<States>();
        expectedListStates.add(new States("10",null,"ニューヨーク"));
        expectedListStates.add(new States("5",null,"カリフォルニア"));
        expectedListStates.add(new States("9",null,"アイオワ"));
        
        expectedListCountries = new ArrayList<Countries>();
        expectedListCountries.add(new Countries("BRA","ブラジル",null));
        expectedListCountries.add(new Countries("CHN","ちゅうごく",null));
        expectedListCountries.add(new Countries("FRA","フランス",null));
        expectedListCountries.add(new Countries("IND","インド",null));
        expectedListCountries.add(new Countries("USA","アメリカ",null));
        
        expectedListSystems1 = new ArrayList<Systems>();
        expectedListSystems1.add(new Systems("現在のシステム",null));
        
        expectedListSystems2 = new ArrayList<Systems>();
        expectedListSystems2.add(new Systems(null,"購入の時間枠"));
    }

    @Test
    public void testGetListCities() throws SQLException {  
        actualListCities = studentRegDAO.getListCities("USA");
        
        assertEquals(expectedListCities.size(), actualListCities.size());
        for (int i = 0; i < expectedListCities.size(); i++) {
            assertEquals(expectedListCities.get(i).getCode(), actualListCities.get(i).getCode()); 
            assertEquals(expectedListCities.get(i).getName(), actualListCities.get(i).getName()); 
        }
    }
    
    @Test
    public void testGetListStates() throws SQLException {  
        actualListStates = studentRegDAO.getListStates("USA");
        
        assertEquals(expectedListStates.size(), actualListStates.size());
        for (int i = 0; i < expectedListStates.size(); i++) {
            assertEquals(expectedListStates.get(i).getCode(), actualListStates.get(i).getCode()); 
            assertEquals(expectedListStates.get(i).getName(), actualListStates.get(i).getName()); 
        }
    }
    
    @Test
    public void testGetListCountries() throws SQLException {  
        actualListCountries = studentRegDAO.getListCountries();
        
        assertEquals(expectedListCountries.size(), actualListCountries.size());
        for (int i = 0; i < expectedListCountries.size(); i++) {
            assertEquals(expectedListCountries.get(i).getCode(), actualListCountries.get(i).getCode()); 
            assertEquals(expectedListCountries.get(i).getName(), actualListCountries.get(i).getName()); 
        }
    }

    @Test
    public void testGetListSystemName() throws SQLException {  
        actualListSystems1 = studentRegDAO.getListSystemName();
        
        assertEquals(expectedListSystems1.size(), actualListSystems1.size());
        for (int i = 0; i < expectedListSystems1.size(); i++) {
            assertEquals(expectedListSystems1.get(i).getSystemName(), actualListSystems1.get(i).getSystemName()); 
        }
    }
    
    @Test
    public void testGetListTimePurchase() throws SQLException {  
        actualListSystems2 = studentRegDAO.getListTimePurchase("現在のシステム");
        
        assertEquals(expectedListSystems2.size(), actualListSystems2.size());
        for (int i = 0; i < expectedListSystems2.size(); i++) {
            assertEquals(expectedListSystems2.get(i).getTimePurchase(), actualListSystems2.get(i).getTimePurchase()); 
        }
    }
    
    @Test
    public void testReg() throws SQLException {  
        /*studentReg = new StudentReg("登録登録", "登録登録登", "xzy", "1", 54964, 6546, "abc@gmail.com", "ABC",
                "11", "10", "abcde", "USA", "現在のシステム", "購入の時間枠", "yzx", "間枠");
        
        assertEquals(true, studentRegDAO.reg(studentReg));*/
        
    }
    
    @Test
    public void testCheckEmail() throws SQLException {  
        assertEquals(true, studentRegDAO.checkEmail("example@email.com"));
        assertEquals(false, studentRegDAO.checkEmail("example@email.vn"));
    }
    
    @Test
    public void testCheckStudent() throws SQLException {  
        assertEquals(true, studentRegDAO.checkStudent(45652,"1"));
        assertEquals(false, studentRegDAO.checkStudent(11111,"1"));
        assertEquals(false, studentRegDAO.checkStudent(45652,"2"));
        assertEquals(false, studentRegDAO.checkStudent(11111,"2"));
    }

}
